use crate::{ constant::*, event::*, state::AdminAccount };

use ::anchor_lang::prelude::*;

pub fn initialize_handler(ctx: Context<Initialize>) -> Result<()> {
    let admin_account = &mut ctx.accounts.admin_account;
    admin_account.admin_key = ctx.accounts.payer.key();
    admin_account.bump = ctx.bumps.admin_account;
    emit!(InitializeEvent {
        initializer: ctx.accounts.payer.key(),
    });
    Ok(())
}

#[derive(Accounts)]
pub struct Initialize<'info> {
    #[account(mut)]
    pub payer: Signer<'info>,
    #[account(
        init,
        payer = payer,
        seeds = [ADMIN_SEED],
        bump,
        space = 8 + AdminAccount::INIT_SPACE
    )]
    pub admin_account: Box<Account<'info, AdminAccount>>,
    pub system_program: Program<'info, System>,
}
