use solana_program::native_token::LAMPORTS_PER_SOL;

use ::{
    anchor_lang::prelude::*,
    anchor_spl::{
        associated_token::AssociatedToken,
        token::{ self, mint_to, Mint, MintTo, Token, TokenAccount, TransferChecked },
    },
};
use crate::{ constant::*, state::*, event::*, error::* };

const PRECISION: u128 = 1_000_000_000;

pub fn reward_handler(ctx: Context<RewardsStruct>) -> Result<()> {
    let user_account = &mut ctx.accounts.user_account;
    let reward_account = &mut ctx.accounts.reward_account;
    let mint_account = &ctx.accounts.mint_account;

    let signer_seeds: &[&[&[u8]]] = &[&[MINT_PDA_SEED, &[ctx.bumps.mint_account]]];
    let current_timestamp = Clock::get()?.unix_timestamp as u64;

    update_global_reward(reward_account, current_timestamp)?;

    // Calculate user's pending rewards
    let pending_rewards = calculate_pending_rewards(user_account, reward_account)?;

    // Update user's accumulated rewards
    user_account.accumulated_rewards = user_account.accumulated_rewards + pending_rewards;

    // Update user's reward debt
    user_account.reward_debt =
        (user_account.stake_amount as u128) * reward_account.accumulated_reward_per_token;

    let mut reward_amount = user_account.accumulated_rewards as f64;
    // Reset user's accumulated rewards
    user_account.accumulated_rewards = 0.0;

    if reward_amount > 0.0 {
        // Update the last claim timestamp to the current time
        user_account.withdrawed_amount += reward_amount;

        reward_amount = reward_amount * (LAMPORTS_PER_SOL as f64);
        let a = reward_amount as u64;
        let mut total_reward = (a * 90) / 100;

        let staking_fee_account = &mut ctx.accounts.staking_fee_account;

        if staking_fee_account.staking_fee > 0.0 {
            let r = ((reward_amount as f64) * staking_fee_account.staking_fee) / 100.0;
            total_reward = total_reward - (r as u64);

            let etf = r as u64;
            token::mint_to(
                CpiContext::new(ctx.accounts.token_program.to_account_info(), MintTo {
                    mint: ctx.accounts.mint_account.to_account_info(),
                    to: ctx.accounts.treasury_wallet_token_ata.to_account_info(),
                    authority: ctx.accounts.mint_account.to_account_info(), // PDA mint authority, required as signer
                }).with_signer(signer_seeds),
                etf
            )?;
        }

        // Mint the total reward to the user's ATA
        mint_to(
            CpiContext::new(ctx.accounts.token_program.to_account_info(), MintTo {
                mint: mint_account.to_account_info(),
                to: ctx.accounts.user_token_ata.to_account_info(),
                authority: mint_account.to_account_info(),
            }).with_signer(signer_seeds),
            total_reward
        )?;

        // Calculate and transfer 10% fee to the treasury wallet
        let fee_amount = ((reward_amount as u64) * 10) / 100;

        // Call transfer inline to avoid the multiple borrow conflict
        token::mint_to(
            CpiContext::new(ctx.accounts.token_program.to_account_info(), MintTo {
                mint: ctx.accounts.mint_account.to_account_info(),
                to: ctx.accounts.treasury_wallet_token_ata.to_account_info(),
                authority: ctx.accounts.mint_account.to_account_info(),
            }).with_signer(signer_seeds),
            fee_amount
        )?;

        user_account.stake_rewards += reward_amount / (LAMPORTS_PER_SOL as f64);

        if user_account.level > 0 && user_account.level < 7 {
            // Referral rewards: if the user was referred, mint referral rewards to referrer’s ATA
            if let Some(referrer_account) = &mut ctx.accounts.referrer_account {
                // check the referrer is correct or not

                let level = referrer_account.level;

                if level == 1 {
                    if user_account.referred_code != Pubkey::default() {
                        let referrer_ata_pubkey =
                            anchor_spl::associated_token::get_associated_token_address(
                                &referrer_account.wallet_address,
                                &ctx.accounts.mint_account.key()
                            );

                        if
                            referrer_ata_pubkey !=
                            ctx.accounts.referrer_token_ata.as_ref().unwrap().key()
                        {
                            return Err(StakeProgramError::InvalidReferralInfo.into());
                        }

                        total_reward = (total_reward * 90) / 100;
                        let referral_rewards = (total_reward * 10) / 100;
                        let fee = (referral_rewards * 10) / 100;
                        let mut reward = (referral_rewards * 90) / 100;

                        let staking_fee_account = &mut ctx.accounts.staking_fee_account;
                        if staking_fee_account.staking_fee > 0.0 {
                            let r =
                                ((referral_rewards as f64) * staking_fee_account.staking_fee) /
                                100.0;
                            reward = reward - (r as u64);
                            let etf = r as u64;
                            token::mint_to(
                                CpiContext::new(
                                    ctx.accounts.token_program.to_account_info(),
                                    MintTo {
                                        mint: ctx.accounts.mint_account.to_account_info(),
                                        to: ctx.accounts.treasury_wallet_token_ata.to_account_info(),
                                        authority: ctx.accounts.mint_account.to_account_info(),
                                    }
                                ).with_signer(signer_seeds),
                                etf
                            )?;
                        }

                        // Mint referral reward to the referrer's ATA
                        mint_to(
                            CpiContext::new(ctx.accounts.token_program.to_account_info(), MintTo {
                                mint: mint_account.to_account_info(),
                                to: ctx.accounts.referrer_token_ata
                                    .as_ref()
                                    .unwrap()
                                    .to_account_info(),
                                authority: mint_account.to_account_info(),
                            }).with_signer(signer_seeds),
                            reward
                        )?;

                        // 10% referral reward goes to the treasury wallet
                        mint_to(
                            CpiContext::new(ctx.accounts.token_program.to_account_info(), MintTo {
                                mint: mint_account.to_account_info(),
                                to: ctx.accounts.treasury_wallet_token_ata.to_account_info(),
                                authority: mint_account.to_account_info(),
                            }).with_signer(signer_seeds),
                            fee
                        )?;

                        referrer_account.referral_rewards +=
                            (referral_rewards as f64) / (LAMPORTS_PER_SOL as f64);
                    }
                }
            }
        }
    }

    emit!(WithdrawRewardEvent {
        user: ctx.accounts.payer.key(),
        withdraw_amount_with_taxes: reward_amount / (LAMPORTS_PER_SOL as f64),
    });

    Ok(())
}

fn update_global_reward(reward_account: &mut RewardAccount, current_timestamp: u64) -> Result<()> {
    if reward_account.total_staked == 0 {
        reward_account.last_update_time = current_timestamp;
        return Ok(());
    }

    let time_diff = current_timestamp - reward_account.last_update_time;
    let seconds_per_year: u64 = 365 * 86400;

    // Convert APY to a decimal (e.g., 100% APY becomes 1.0)
    let apy_decimal = reward_account.apy_rate / 100.0;

    // Calculate reward per token
    let reward_per_token = (apy_decimal * (time_diff as f64)) / (seconds_per_year as f64);

    // Scale reward per token to prevent floating-point inaccuracies
    let reward_per_token_scaled = (reward_per_token * (PRECISION as f64)) as u128;

    // Update accumulated_reward_per_token
    reward_account.accumulated_reward_per_token =
        reward_account.accumulated_reward_per_token.saturating_add(reward_per_token_scaled);

    // Update last_update_time
    reward_account.last_update_time = current_timestamp;

    Ok(())
}

fn calculate_pending_rewards(
    user_account: &UserAccount,
    reward_account: &RewardAccount
) -> Result<f64> {
    let pending_rewards_float =
        ((user_account.stake_amount as f64) *
            ((reward_account.accumulated_reward_per_token as f64) -
                (user_account.reward_debt as f64))) /
        (PRECISION as f64);

    Ok(pending_rewards_float)
}

#[derive(Accounts)]
pub struct RewardsStruct<'info> {
    #[account(mut)]
    pub payer: Signer<'info>,

    #[account(
        mut,
        seeds = [USER_SEED, payer.key().as_ref()],
        bump = user_account.bump
    )]
    pub user_account: Box<Account<'info, UserAccount>>,

    #[account(
        mut,
        seeds = [APY_REWARDS_SEED],
        bump,
    )]
    pub reward_account: Box<Account<'info, RewardAccount>>,

    #[account(
        mut, 
        seeds = [MINT_PDA_SEED],
        bump,
    )]
    pub mint_account: Account<'info, Mint>,

    #[account(mut)]
    pub user_token_ata: Box<Account<'info, TokenAccount>>,
    #[account(
        mut, 
        seeds = [ADMIN_SEED],
        bump =  admin_account.bump,
    )]
    pub admin_account: Account<'info, AdminAccount>,

    #[account(
        mut,
        associated_token::mint = mint_account,
        associated_token::authority = admin_account.admin_key
    )]
    pub treasury_wallet_token_ata: Box<Account<'info, TokenAccount>>,
    // Optionally fetch the referred user's referral state
    #[account(
        mut,
        seeds = [USER_SEED, user_account.referred_code.as_ref()],
        bump = referrer_account.bump,
    )]
    pub referrer_account: Option<Account<'info, UserAccount>>,
    #[account( 
        mut,
        seeds = [STAKE_FEE_SEED],
        bump = staking_fee_account.bump
    )]
    pub staking_fee_account: Box<Account<'info, StakingFeeAccount>>,
    #[account(mut)]
    pub referrer_token_ata: Option<Account<'info, TokenAccount>>,

    pub token_program: Program<'info, Token>,
    pub associated_token_program: Program<'info, AssociatedToken>,
    pub system_program: Program<'info, System>,
    pub rent: Sysvar<'info, Rent>,
}

impl<'info> RewardsStruct<'info> {
    pub fn transfer_token_to_treasury_wallet_token_ata(
        &self
    ) -> CpiContext<'_, '_, '_, 'info, TransferChecked<'info>> {
        let cpi_accounts = TransferChecked {
            from: self.user_token_ata.to_account_info(),
            mint: self.mint_account.to_account_info(),
            to: self.treasury_wallet_token_ata.to_account_info(),
            authority: self.payer.to_account_info(),
        };
        CpiContext::new(self.token_program.to_account_info(), cpi_accounts)
    }
}
