use anchor_lang::prelude::*;

#[error_code]
pub enum StakeProgramError {
    #[msg("Unauthorized access")]
    Unauthorized,
    #[msg("Staking fee should be 0.0 to 25.0")]
    InvalidStakingFeeAmount,
    #[msg("Referral code is wrong")]
    InvalidReferralInfo,
    #[msg("User already created referral code")]
    ReferralCodeAlreadyGenerated,
    #[msg("Referrer account is required when referred code is provided")]
    ReferrerAccountMissing,
}
