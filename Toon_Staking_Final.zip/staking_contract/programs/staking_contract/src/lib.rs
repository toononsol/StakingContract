use anchor_lang::prelude::*;

pub mod constant;
pub mod error;
pub mod state;
pub mod event;
pub mod processor;
use crate::processor::*;

declare_id!("4qSFjJLT2k4bkCr3TDrQV2VFAgkxvG3PVL6qfKLrdgBn");

#[program]
pub mod staking_contract {
    use super::*;

    pub fn initialize(ctx: Context<Initialize>) -> Result<()> {
        initialize::initialize_handler(ctx)
    }
    pub fn referral_code(ctx: Context<Referral>, args: Args) -> Result<()> {
        referral_code::generate_referral_code(ctx, args)
    }

    pub fn create_token(ctx: Context<CreateToken>, args: CreateTokenArgs) -> Result<()> {
        create_token::create_token(ctx, args)
    }


    pub fn apy(ctx: Context<RewardAPY>, args: RewardArgs) -> Result<()> {
        apy::apy_handler(ctx,args)
    }

    pub fn create_stake(ctx: Context<Stake>, args: ArgsStake) -> Result<()> {
        create_stake::stake_handler(ctx, args)
    }


    pub fn withdraw_rewards(ctx: Context<RewardsStruct>) -> Result<()> {
        withdraw_rewards::reward_handler(ctx)
    }
    pub fn staking_fee(ctx: Context<StakingFee>, fee: f64) -> Result<()> {
        staking_fee::staking_fee_handler(ctx, fee)
    }
}
