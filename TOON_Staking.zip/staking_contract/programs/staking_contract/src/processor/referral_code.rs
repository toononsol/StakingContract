use anchor_lang::prelude::*;
use crate::{ constant::*, state::*, error::*, event::* };
use anchor_spl::associated_token::AssociatedToken;
use anchor_spl::token::{ Mint, Token, TokenAccount };

#[derive(AnchorSerialize, AnchorDeserialize)]
pub struct Args {
    pub referred_code: Option<Pubkey>, // Optional referral code
}

pub fn generate_referral_code(ctx: Context<Referral>, args: Args) -> Result<()> {
    if ctx.accounts.user_account.referral_code != Pubkey::default() {
        return Err(StakeProgramError::ReferralCodeAlreadyGenerated.into());
    }

    // If the user is referred, set the level based on the referral chain
    if let Some(referred_code) = args.referred_code {
        // preventing self referral
        if referred_code == ctx.accounts.payer.key() {
            return Err(StakeProgramError::InvalidReferralInfo.into());
        }

        if ctx.accounts.referrer_account.is_none() {
            return Err(StakeProgramError::ReferrerAccountMissing.into());
        }

        // Set the referred code
        ctx.accounts.user_account.referred_code = referred_code;
    }
    let referrer_seed = derive_referrer_seed(&args, &ctx.accounts.user_account);
    // Set common fields for user registration
    if ctx.accounts.user_account.wallet_address == Pubkey::default() {
        ctx.accounts.user_account.wallet_address = ctx.accounts.payer.key();
        ctx.accounts.user_account.bump = ctx.bumps.user_account;
    }

    let user_account = &mut ctx.accounts.user_account;

    // Fetch and validate the referrer account if a referred code is provided
    let referrer_account = if let Some(referrer_account) = &mut ctx.accounts.referrer_account {
        // Derive the expected PDA for validation
        let (expected_pda, _bump) = Pubkey::find_program_address(
            &[USER_SEED, referrer_seed.as_ref()],
            &ctx.program_id
        );

        // Validate that the provided account matches the derived PDA
        if referrer_account.key() != expected_pda {
            return Err(StakeProgramError::InvalidReferralInfo.into());
        }
        Some(referrer_account)
    } else {
        None
    };

    // If user has a referrer, update the chain accordingly
    if user_account.referred_code != Pubkey::default() {
        // Fetch referred state from the referrer
        if let Some(referrer_account) = referrer_account {
            let level = referrer_account.level;
            if level > 0 && level < 7 {
                user_account.level = level + 1;
            } else {
                // do not create any referral chain
                user_account.level = 0;
            }
        }
    } else {
        user_account.level = 1;
    }

    user_account.referral_code = user_account.wallet_address.key();

    emit!(ReferralCodeEvent {
        referral_code: user_account.referral_code,
        referred_code: user_account.referred_code,
    });

    Ok(())
}

#[derive(Accounts)]
pub struct Referral<'info> {
    #[account(mut)]
    pub payer: Signer<'info>,

    #[account(
        init_if_needed,
        seeds = [USER_SEED, payer.key().as_ref()],
        bump,
        payer = payer,
        space = 8 + UserAccount::INIT_SPACE
    )]
    pub user_account: Box<Account<'info, UserAccount>>,

    // Unique referral state for the user

    #[account(
        mut,
        seeds = [MINT_PDA_SEED],
        bump,
    )]
    pub mint_account: Account<'info, Mint>,

    #[account(
        init_if_needed,
        payer = payer,
        associated_token::mint = mint_account,
        associated_token::authority = payer
    )]
    pub user_token_ata: Box<Account<'info, TokenAccount>>,

    // Optionally fetch the referred user's referral state
    #[account(
        mut,
    )]
    pub referrer_account: Option<Account<'info, UserAccount>>,
    pub token_program: Program<'info, Token>,
    pub associated_token_program: Program<'info, AssociatedToken>,
    pub system_program: Program<'info, System>,
}

// Before invoking the handler, derive the appropriate referrer seed
fn derive_referrer_seed(args: &Args, user_account: &Account<UserAccount>) -> Pubkey {
    args.referred_code.unwrap_or(user_account.referred_code)
}
