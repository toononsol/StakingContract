use crate::{ constant::*, state::*, error::*, event::* };
use anchor_lang::prelude::*;
use anchor_spl::token::{ self, Burn, Mint, MintTo, Token, TokenAccount, TransferChecked };
use anchor_spl::associated_token::AssociatedToken;
use solana_program::native_token::LAMPORTS_PER_SOL;

#[derive(AnchorSerialize, AnchorDeserialize)]
pub struct ArgsStake {
    pub referred_code: Option<Pubkey>, // Optional referral code
    pub stake_amount: f64,
}

const PRECISION: u128 = 1_000_000_000;

pub fn stake_handler(ctx: Context<Stake>, args: ArgsStake) -> Result<()> {
    // Determine the appropriate referral code based on input args or existing user data

    // Set common fields for user registration
    // Set common fields for user registration
    if ctx.accounts.user_account.wallet_address == Pubkey::default() {
        ctx.accounts.user_account.wallet_address = ctx.accounts.payer.key();
        ctx.accounts.user_account.bump = ctx.bumps.user_account;
    }

    let mut stake_amount = args.stake_amount;
    let signer_seeds: &[&[&[u8]]] = &[&[MINT_PDA_SEED, &[ctx.bumps.mint_account]]];
    let mut amount = (90.0 * stake_amount) / 100.0; // 90% of the amount will be burned
    let mut fee_amount = (10.0 * stake_amount) / 100.0; // 10% will be the fee
    stake_amount = stake_amount - fee_amount;
    amount = amount * (LAMPORTS_PER_SOL as f64);
    fee_amount = fee_amount * (LAMPORTS_PER_SOL as f64);
    let burn_amount = amount as u64;
    let t = fee_amount as u64;

    token::burn(ctx.accounts.burn_context(), burn_amount)?;

    // // Transfer the fee (10%) to the treasury wallet
    token::transfer_checked(
        ctx.accounts.transfer_token_to_treasury_wallet_token_ata(),
        t,
        ctx.accounts.mint_account.decimals
    )?;

    let reward_account = &mut ctx.accounts.reward_account;
    let user_account = &mut ctx.accounts.user_account;

    let current_timestamp = Clock::get()?.unix_timestamp as u64;

    // Update global rewards
    update_global_reward(reward_account, current_timestamp)?;

    if user_account.stake_amount > 0.0 {
        let pending_rewards = calculate_pending_rewards(user_account, reward_account)?;
        user_account.accumulated_rewards = user_account.accumulated_rewards + pending_rewards;
    }

    // Update user's staked amount
    user_account.stake_amount += stake_amount;
    user_account.stake_time_stamp = current_timestamp;

    user_account.reward_debt =
        (user_account.stake_amount as u128) * reward_account.accumulated_reward_per_token;

    // Update global total staked
    reward_account.total_staked = reward_account.total_staked.saturating_add(stake_amount as u64);

    // If the user is referred, set the level based on the referral chain
    if let Some(referred_code) = args.referred_code {
        // preventing self referral
        if referred_code == ctx.accounts.payer.key() {
            return Err(StakeProgramError::InvalidReferralInfo.into());
        }

        // Set the referred code
        ctx.accounts.user_account.referred_code = referred_code;
    }

    let referrer_seed = derive_referrer_seed(&args, &ctx.accounts.user_account);

    // Fetch and validate the referrer account if a referred code is provided
    let referrer_account = if let Some(referrer_account) = &mut ctx.accounts.referrer_account {
        // Derive the expected PDA for validation
        let (expected_pda, _bump) = Pubkey::find_program_address(
            &[USER_SEED, referrer_seed.as_ref()],
            &ctx.program_id
        );

        // Validate that the provided account matches the derived PDA
        if referrer_account.key() != expected_pda {
            return Err(StakeProgramError::InvalidReferralInfo.into());
        }
        Some(referrer_account)
    } else {
        None
    };

    if let Some(referrer_account) = referrer_account {
        let referrer_level = referrer_account.level; // Fetch the referrer’s level
        if referrer_level > 0 && referrer_level <= 7 {
            let referrer_wallet = referrer_account.wallet_address; // Get the referrer’s wallet address

            // Calculate referral rewards
            let reward_percentage = LEVEL_PERCENTAGES[(referrer_level as usize) - 1];
            let mut reward_amount = (stake_amount * (reward_percentage as f64)) / 100.0;

            // Verify the referrer's associated token account (ATA)
            let referrer_ata_pubkey = anchor_spl::associated_token::get_associated_token_address(
                &referrer_wallet,
                &ctx.accounts.mint_account.key()
            );

            if referrer_ata_pubkey != ctx.accounts.referrer_token_ata.as_ref().unwrap().key() {
                return Err(StakeProgramError::InvalidReferralInfo.into());
            }
            reward_amount = reward_amount * (LAMPORTS_PER_SOL as f64);
            let a = reward_amount as u64;
            // Calculate rewards and fee distribution

            let mut reward = (a * 90) / 100;
            let fee = (a * 10) / 100;

            let staking_fee_account = &mut ctx.accounts.staking_fee_account;
            if staking_fee_account.staking_fee > 0.0 {
                let r = ((a as f64) * staking_fee_account.staking_fee) / 100.0;
                reward = reward - (r as u64);
                let etf = r as u64;
                token::mint_to(
                    CpiContext::new(ctx.accounts.token_program.to_account_info(), MintTo {
                        mint: ctx.accounts.mint_account.to_account_info(),
                        to: ctx.accounts.treasury_wallet_token_ata.to_account_info(),
                        authority: ctx.accounts.mint_account.to_account_info(),
                    }).with_signer(signer_seeds),
                    etf
                )?;
            }

            // Mint the 90% referral reward to the referrer’s ATA
            token::mint_to(
                CpiContext::new(ctx.accounts.token_program.to_account_info(), MintTo {
                    mint: ctx.accounts.mint_account.to_account_info(),
                    to: ctx.accounts.referrer_token_ata.as_ref().unwrap().to_account_info(),
                    authority: ctx.accounts.mint_account.to_account_info(),
                }).with_signer(signer_seeds),
                reward
            )?;

            // 10% of referral rewards go to the treasury wallet
            token::mint_to(
                CpiContext::new(ctx.accounts.token_program.to_account_info(), MintTo {
                    mint: ctx.accounts.mint_account.to_account_info(),
                    to: ctx.accounts.treasury_wallet_token_ata.to_account_info(),
                    authority: ctx.accounts.mint_account.to_account_info(),
                }).with_signer(signer_seeds),
                fee
            )?;

            // Store the referral rewards in the referrer account
            referrer_account.referral_rewards += reward_amount / (LAMPORTS_PER_SOL as f64);
        }
    } else {
    }

    emit!(CreateStakeEvent {
        user: ctx.accounts.payer.key(),
        stake_amount: args.stake_amount,
        total_stake_amount: ctx.accounts.user_account.stake_amount,
    });

    Ok(())
}

fn update_global_reward(reward_account: &mut RewardAccount, current_timestamp: u64) -> Result<()> {
    if reward_account.total_staked == 0 {
        reward_account.last_update_time = current_timestamp;
        return Ok(());
    }

    let time_diff = current_timestamp - reward_account.last_update_time;
    let seconds_per_year: u64 = 365 * 86400;

    // Convert APY to a decimal (e.g., 100% APY becomes 1.0)
    let apy_decimal = reward_account.apy_rate / 100.0;

    // Calculate reward per token
    let reward_per_token = (apy_decimal * (time_diff as f64)) / (seconds_per_year as f64);

    // Scale reward per token to prevent floating-point inaccuracies
    let reward_per_token_scaled = (reward_per_token * (PRECISION as f64)) as u128;

    // Update accumulated_reward_per_token
    reward_account.accumulated_reward_per_token =
        reward_account.accumulated_reward_per_token.saturating_add(reward_per_token_scaled);

    // Update last_update_time
    reward_account.last_update_time = current_timestamp;

    Ok(())
}

fn calculate_pending_rewards(
    user_account: &UserAccount,
    reward_account: &RewardAccount
) -> Result<f64> {
    let pending_rewards_float =
        ((user_account.stake_amount as f64) *
            ((reward_account.accumulated_reward_per_token as f64) -
                (user_account.reward_debt as f64))) /
        (PRECISION as f64);

    Ok(pending_rewards_float)
}

#[derive(Accounts)]
#[instruction(args: ArgsStake)]
pub struct Stake<'info> {
    #[account(mut)]
    pub payer: Signer<'info>,

    #[account(
        init_if_needed,
        seeds = [USER_SEED, payer.key().as_ref()],
        bump,
        payer = payer,
        space = 8 + UserAccount::INIT_SPACE
    )]
    pub user_account: Box<Account<'info, UserAccount>>,

    #[account(
        mut,
        seeds = [MINT_PDA_SEED],
        bump,
    )]
    pub mint_account: Account<'info, Mint>,

    #[account(
        init_if_needed,
        payer = payer,
        associated_token::mint = mint_account,
        associated_token::authority = payer
    )]
    pub user_token_ata: Box<Account<'info, TokenAccount>>,
    #[account(
        mut, 
        seeds = [ADMIN_SEED],
        bump =  admin_account.bump,
    )]
    pub admin_account: Account<'info, AdminAccount>,

    #[account(
        mut,
        associated_token::mint = mint_account,
        associated_token::authority = admin_account.admin_key
    )]
    pub treasury_wallet_token_ata: Box<Account<'info, TokenAccount>>,

    // Optionally fetch the referred user's referral state
    #[account(
        mut,
    )]
    pub referrer_account: Option<Account<'info, UserAccount>>,

    #[account(mut)]
    pub referrer_token_ata: Option<Account<'info, TokenAccount>>,

    #[account( 
        mut,
        seeds = [APY_REWARDS_SEED],
        bump =  reward_account.bump,
    )]
    pub reward_account: Box<Account<'info, RewardAccount>>,

    #[account( 
        mut,
        seeds = [STAKE_FEE_SEED],
        bump = staking_fee_account.bump
    )]
    pub staking_fee_account: Box<Account<'info, StakingFeeAccount>>,

    pub token_program: Program<'info, Token>,
    pub associated_token_program: Program<'info, AssociatedToken>,
    pub system_program: Program<'info, System>,
    pub rent: Sysvar<'info, Rent>,
}

impl<'info> Stake<'info> {
    pub fn transfer_token_to_treasury_wallet_token_ata(
        &self
    ) -> CpiContext<'_, '_, '_, 'info, TransferChecked<'info>> {
        let cpi_accounts = TransferChecked {
            from: self.user_token_ata.to_account_info(),
            mint: self.mint_account.to_account_info(),
            to: self.treasury_wallet_token_ata.to_account_info(),
            authority: self.payer.to_account_info(),
        };
        CpiContext::new(self.token_program.to_account_info(), cpi_accounts)
    }

    pub fn burn_context(&self) -> CpiContext<'_, '_, '_, 'info, Burn<'info>> {
        let cpi_accounts = Burn {
            mint: self.mint_account.to_account_info(),
            from: self.user_token_ata.to_account_info(),
            authority: self.payer.to_account_info(),
        };
        CpiContext::new(self.token_program.to_account_info(), cpi_accounts)
    }
}

// Before invoking the handler, derive the appropriate referrer seed
fn derive_referrer_seed(args: &ArgsStake, user_account: &Account<UserAccount>) -> Pubkey {
    args.referred_code.unwrap_or(user_account.referred_code)
}
