use anchor_lang::prelude::*;

#[account]
#[derive(Default, InitSpace)]
pub struct UserAccount {
    pub wallet_address: Pubkey,
    pub level: u64,
    pub stake_amount: f64, // Vector to store [stake_amount, timestamp]
    pub neg_rewards: f64,
    pub stake_time_stamp: u64,
    pub referred_code: Pubkey,
    pub stake_rewards: f64,
    pub referral_rewards: f64,
    pub referral_code: Pubkey,
    pub bump: u8,
    pub calculated_rewards: f64,
    pub withdrawed_amount: f64,
    pub reward_debt: u128,
    pub accumulated_rewards: f64,
}

#[account]
#[derive(Default, InitSpace)]
pub struct RewardAccount {
    pub apy_rate: f64,
    pub accumulated_reward_per_token: u128,
    pub last_update_time: u64,
    pub total_staked: u64,
    pub bump: u8,
}

#[account]
#[derive(Default, InitSpace)]
pub struct StakingFeeAccount {
    pub staking_fee: f64,
    pub bump: u8,
}

#[account]
#[derive(Default, InitSpace)]
pub struct AdminAccount {
    pub admin_key: Pubkey,
    pub bump: u8,
}
