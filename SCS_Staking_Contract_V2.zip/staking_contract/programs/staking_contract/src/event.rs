
use anchor_lang::prelude::*;

#[event]
pub struct InitializeEvent {
    pub initializer: Pubkey, 
}

#[event]
pub struct APYEvent {
    pub apy_rate: f64,
    pub previous_apy_rewards: f64,
    pub apy_time_stamp: u64,
}

#[event]
pub struct TokenCreationEvent {
    pub mint_address: Pubkey,
    pub initial_mint_amount: u64,
}


#[event]
pub struct ReferralCodeEvent{
    pub referral_code: Pubkey,
    pub referred_code: Pubkey,
}

#[event]
pub struct StakingFeeEvent{
    pub staking_fee: f64,
}

#[event]
pub struct WithdrawRewardEvent{
    pub user: Pubkey,
    pub withdraw_amount_with_taxes: f64,
}

#[event]
pub struct CreateStakeEvent{
    pub user: Pubkey,
    pub stake_amount: f64,
    pub total_stake_amount: f64,
}

