use solana_program::native_token::LAMPORTS_PER_SOL;

use ::{
    anchor_lang::prelude::*,
    anchor_spl::{
        associated_token::AssociatedToken,
        token::{ self, mint_to, Mint, MintTo, Token, TokenAccount, TransferChecked },
    },
};
use crate::{ constant::*, state::*, event::*, error::* };

pub fn reward_handler(ctx: Context<RewardsStruct>) -> Result<()> {
    let user_account = &mut ctx.accounts.user_account;
    let reward_account = &ctx.accounts.reward_account;
    let mint_account = &ctx.accounts.mint_account;

    let signer_seeds: &[&[&[u8]]] = &[&[MINT_PDA_SEED, &[ctx.bumps.mint_account]]];
    let current_timestamp = Clock::get()?.unix_timestamp as u64;

    // Time difference since the last APY update, in seconds
    let mut time_diff = current_timestamp - reward_account.apy_time_stamp;
    let mut flag = false;
    if time_diff > current_timestamp - user_account.stake_time_stamp {
        time_diff = current_timestamp - user_account.stake_time_stamp;
        flag = true;
    }

    // Calculate APY per second (convert yearly APY to per-second APY)
    let seconds_per_year: u64 = 365 * 86400; // Total number of seconds in a year
    let per_second_apy_rate = reward_account.apy_rate / (100.0 * (seconds_per_year as f64)); // APY per second

    // Calculate the total reward amount:
    // Accumulate rewards for staked amount over the elapsed time (in seconds)
    let mut reward_amount;

    if flag {
        reward_amount =
            user_account.calculated_rewards +
            per_second_apy_rate * (user_account.stake_amount as f64) * (time_diff as f64) -
            user_account.neg_rewards * (user_account.stake_amount as f64);
    } else {
        reward_amount =
            user_account.calculated_rewards + // Already accumulated rewards
            per_second_apy_rate * (user_account.stake_amount as f64) * (time_diff as f64) + // New rewards for elapsed time
            reward_account.previous_apy_rewards * (user_account.stake_amount as f64) - // Include previous APY rewards
            user_account.neg_rewards * (user_account.stake_amount as f64); // Subtract negative rewards if applicable
    }

    if reward_amount > 0.0 {
        // Update the last claim timestamp to the current time
        user_account.stake_time_stamp = current_timestamp;
        user_account.withdrawed_amount += reward_amount;
        user_account.neg_rewards = 0.0;
        reward_amount = reward_amount * (LAMPORTS_PER_SOL as f64);
        let a = reward_amount as u64;
        let mut total_reward = (a * 90) / 100;

        let staking_fee_account = &mut ctx.accounts.staking_fee_account;
        if staking_fee_account.staking_fee > 0.0 {
            let r = ((reward_amount as f64) * staking_fee_account.staking_fee) / 100.0;
            total_reward = total_reward - (r as u64);

            let etf = r as u64;
            token::mint_to(
                CpiContext::new(ctx.accounts.token_program.to_account_info(), MintTo {
                    mint: ctx.accounts.mint_account.to_account_info(),
                    to: ctx.accounts.treasury_wallet_token_ata.to_account_info(),
                    authority: ctx.accounts.mint_account.to_account_info(),
                }).with_signer(signer_seeds),
                etf
            )?;
        }

        // Mint the total reward to the user's ATA
        mint_to(
            CpiContext::new(ctx.accounts.token_program.to_account_info(), MintTo {
                mint: mint_account.to_account_info(),
                to: ctx.accounts.user_token_ata.to_account_info(),
                authority: mint_account.to_account_info(),
            }).with_signer(signer_seeds),
            total_reward
        )?;

        // Calculate and transfer 10% fee to the treasury wallet
        let fee_amount = ((reward_amount as u64) * 10) / 100;

        // Call transfer inline to avoid the multiple borrow conflict
        token::mint_to(
            CpiContext::new(ctx.accounts.token_program.to_account_info(), MintTo {
                mint: ctx.accounts.mint_account.to_account_info(),
                to: ctx.accounts.treasury_wallet_token_ata.to_account_info(),
                authority: ctx.accounts.mint_account.to_account_info(),
            }).with_signer(signer_seeds),
            fee_amount
        )?;

        user_account.stake_rewards += reward_amount / (LAMPORTS_PER_SOL as f64);
        user_account.calculated_rewards = 0.0;

        if user_account.level > 0 && user_account.level < 7 {
            // Referral rewards: if the user was referred, mint referral rewards to referrer’s ATA
            if let Some(referrer_account) = &mut ctx.accounts.referrer_account {
                // check the referrer is correct or not

                let level = referrer_account.level;

                if level == 1 {
                    if user_account.referred_code != Pubkey::default() {
                        let referrer_ata_pubkey =
                            anchor_spl::associated_token::get_associated_token_address(
                                &referrer_account.wallet_address,
                                &ctx.accounts.mint_account.key()
                            );

                        if
                            referrer_ata_pubkey !=
                            ctx.accounts.referrer_token_ata.as_ref().unwrap().key()
                        {
                            return Err(StakeProgramError::InvalidReferralInfo.into());
                        }

                        total_reward = (total_reward * 90) / 100;
                        let referral_rewards = (total_reward * 10) / 100;
                        let fee = (referral_rewards * 10) / 100;
                        let mut reward = (referral_rewards * 90) / 100;

                        let staking_fee_account = &mut ctx.accounts.staking_fee_account;
                        if staking_fee_account.staking_fee > 0.0 {
                            let r =
                                ((referral_rewards as f64) * staking_fee_account.staking_fee) /
                                100.0;
                            reward = reward - (r as u64);
                            let etf = r as u64;
                            token::mint_to(
                                CpiContext::new(
                                    ctx.accounts.token_program.to_account_info(),
                                    MintTo {
                                        mint: ctx.accounts.mint_account.to_account_info(),
                                        to: ctx.accounts.treasury_wallet_token_ata.to_account_info(),
                                        authority: ctx.accounts.mint_account.to_account_info(),
                                    }
                                ).with_signer(signer_seeds),
                                etf
                            )?;
                        }

                        // Mint referral reward to the referrer's ATA
                        mint_to(
                            CpiContext::new(ctx.accounts.token_program.to_account_info(), MintTo {
                                mint: mint_account.to_account_info(),
                                to: ctx.accounts.referrer_token_ata
                                    .as_ref()
                                    .unwrap()
                                    .to_account_info(),
                                authority: mint_account.to_account_info(),
                            }).with_signer(signer_seeds),
                            reward
                        )?;

                        // 10% referral reward goes to the treasury wallet
                        mint_to(
                            CpiContext::new(ctx.accounts.token_program.to_account_info(), MintTo {
                                mint: mint_account.to_account_info(),
                                to: ctx.accounts.treasury_wallet_token_ata.to_account_info(),
                                authority: mint_account.to_account_info(),
                            }).with_signer(signer_seeds),
                            fee
                        )?;

                        referrer_account.referral_rewards +=
                            (referral_rewards as f64) / (LAMPORTS_PER_SOL as f64);
                    }
                }
            }
        }
    }

    emit!(WithdrawRewardEvent {
        user: ctx.accounts.payer.key(),
        withdraw_amount_with_taxes: reward_amount / (LAMPORTS_PER_SOL as f64),
    });

    Ok(())
}

#[derive(Accounts)]
pub struct RewardsStruct<'info> {
    #[account(mut)]
    pub payer: Signer<'info>,

    #[account(
        mut,
        seeds = [USER_SEED, payer.key().as_ref()],
        bump = user_account.bump
    )]
    pub user_account: Box<Account<'info, UserAccount>>,

    #[account(
        mut,
        seeds = [APY_REWARDS_SEED],
        bump,
    )]
    pub reward_account: Box<Account<'info, RewardAccount>>,

    #[account(
        mut, 
        seeds = [MINT_PDA_SEED],
        bump,
    )]
    pub mint_account: Account<'info, Mint>,

    #[account(mut)]
    pub user_token_ata: Box<Account<'info, TokenAccount>>,
    #[account(
        mut, 
        seeds = [MINT_PDA_SEED],
        bump =  admin_account.bump,
    )]
    pub admin_account: Account<'info, AdminAccount>,

    #[account(
        associated_token::mint = mint_account,
        associated_token::authority = admin_account.admin_key
    )]
    pub treasury_wallet_token_ata: Box<Account<'info, TokenAccount>>,
    // Optionally fetch the referred user's referral state
    #[account(
        mut,
        seeds = [USER_SEED, user_account.referred_code.as_ref()],
        bump = referrer_account.bump,
    )]
    pub referrer_account: Option<Account<'info, UserAccount>>,
    #[account( 
        mut,
        seeds = [STAKE_FEE_SEED],
        bump = staking_fee_account.bump
    )]
    pub staking_fee_account: Box<Account<'info, StakingFeeAccount>>,
    #[account(mut)]
    pub referrer_token_ata: Option<Account<'info, TokenAccount>>,

    pub token_program: Program<'info, Token>,
    pub associated_token_program: Program<'info, AssociatedToken>,
    pub system_program: Program<'info, System>,
    pub rent: Sysvar<'info, Rent>,
}

impl<'info> RewardsStruct<'info> {
    pub fn transfer_token_to_treasury_wallet_token_ata(
        &self
    ) -> CpiContext<'_, '_, '_, 'info, TransferChecked<'info>> {
        let cpi_accounts = TransferChecked {
            from: self.user_token_ata.to_account_info(),
            mint: self.mint_account.to_account_info(),
            to: self.treasury_wallet_token_ata.to_account_info(),
            authority: self.payer.to_account_info(),
        };
        CpiContext::new(self.token_program.to_account_info(), cpi_accounts)
    }
}
