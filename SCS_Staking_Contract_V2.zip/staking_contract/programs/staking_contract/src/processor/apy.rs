use anchor_lang::prelude::*;
use crate::{ constant::*, state::*, event::*, error::* };

pub fn apy_handler(ctx: Context<RewardAPY>, reward_rate: f64) -> Result<()> {
    if ctx.accounts.admin_account.admin_key.key() != ctx.accounts.payer.key() {
        return Err(StakeProgramError::Unauthorized.into());
    }

    let current_timestamp = Clock::get()?.unix_timestamp as u64;
    let reward_account = &mut ctx.accounts.reward_account;

    if reward_account.apy_rate > 0.0 {
        // Calculate time period in seconds
        let time_period = current_timestamp - reward_account.apy_time_stamp;

        // Calculate APY per second (convert yearly APY to per-second APY)
        let seconds_per_year: u64 = 365 * 86400; // Seconds in a year
        let per_second_apy_rate = reward_account.apy_rate / (100.0 * (seconds_per_year as f64)); // APY per second

        // Accumulate previous rewards for the time period in seconds
        let previous_apy_rewards = reward_account.previous_apy_rewards;
        let new_rewards = (time_period as f64) * per_second_apy_rate + previous_apy_rewards;

        // Update the accumulated rewards
        reward_account.previous_apy_rewards = new_rewards;
    } else {
        reward_account.previous_apy_rewards = 0.0; // Reset for the next cycle
    }

    // Update APY rate and timestamp for the next cycle
    reward_account.apy_rate = reward_rate;
    reward_account.apy_time_stamp = current_timestamp;
    reward_account.bump = ctx.bumps.reward_account;

    emit!(APYEvent {
        apy_rate: reward_account.apy_rate,
        previous_apy_rewards: reward_account.previous_apy_rewards,
        apy_time_stamp: reward_account.apy_time_stamp,
    });
    Ok(())
}

#[derive(Accounts)]
pub struct RewardAPY<'info> {
    #[account(mut)]
    pub payer: Signer<'info>,
    #[account(
        init_if_needed,
        payer = payer,
        seeds = [APY_REWARDS_SEED],
        bump,
        space = 8 + RewardAccount::INIT_SPACE
    )]
    pub reward_account: Box<Account<'info, RewardAccount>>,

    #[account(
        mut, 
        seeds = [MINT_PDA_SEED],
        bump =  admin_account.bump,
    )]
    pub admin_account: Account<'info, AdminAccount>,

    pub system_program: Program<'info, System>,
}
