use anchor_lang::prelude::*;

#[event]
pub struct InitializeEvent{
    pub initializer: Pubkey,
    pub stake_token: Pubkey,
    
}