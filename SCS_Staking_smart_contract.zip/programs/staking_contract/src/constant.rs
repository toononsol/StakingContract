pub const STAKE_PROGRAM_SEED: &[u8] = b"STAKE_PROGRAM_SEED";
pub static LEVEL_PERCENTAGES: [u64;7] = [10,5,3,2,2,1,1];
pub const USER_SEED: &[u8] = b"USER";
pub const REFERRED_SEED: &[u8] = b"REFERRED_SEED";
pub const MINT_PDA_SEED: &[u8] = b"mint";
pub const METADATA_PDA_SEED: &[u8] = b"metadata";
pub const APY_REWARDS_SEED: &[u8] = b"APY_REWARDS_SEED";
pub const STAKE_FEE_SEED: &[u8] = b"EXTRA_FEE_SEED";