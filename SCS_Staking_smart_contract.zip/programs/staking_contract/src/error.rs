use anchor_lang::prelude::*;

#[error_code]
pub enum StakeProgramError {
    #[msg("Unauthorized access")]
    Unauthorized,
    #[msg("Invalid Funds amaount")]
    InvalidFundsAmount,
    #[msg("Invalid withdraw amount")]
    InvalidFundsWithdrawAmount,
    #[msg("User is already registered")]
    UserAlreadyRegistered,
    #[msg("Referral code is wrong ")]
    InvalidReferralInfo,
    #[msg("Stake amount vector is full.")]
    StakeAmountVectorFull,
    #[msg("user associated token account address is not available")]
    AccountNotFound,
}
