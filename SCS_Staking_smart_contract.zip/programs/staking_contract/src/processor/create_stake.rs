use crate::{ constant::*, state::*, error::* };
use anchor_lang::prelude::*;
use anchor_spl::token::{ self, Burn, Mint, MintTo, Token, TokenAccount, TransferChecked };
use anchor_spl::associated_token::AssociatedToken;
use solana_program::native_token::LAMPORTS_PER_SOL;

#[derive(AnchorSerialize, AnchorDeserialize)]
pub struct ArgsStake {
    pub referred_code: Option<Pubkey>, // Optional referral code
    pub stake_amount: f64,
}

pub fn stake_handler(ctx: Context<Stake>, args: ArgsStake) -> Result<()> {
    // Determine the appropriate referral code based on input args or existing user data

    // Set common fields for user registration
    // Set common fields for user registration
    if ctx.accounts.user_account.wallet_address == Pubkey::default() {
        ctx.accounts.user_account.wallet_address = ctx.accounts.payer.key();
        ctx.accounts.user_account.bump = ctx.bumps.user_account;
    }

    let mut stake_amount = args.stake_amount;
    let signer_seeds: &[&[&[u8]]] = &[&[MINT_PDA_SEED, &[ctx.bumps.mint_account]]];
    let mut amount = (90.0 * stake_amount) / 100.0; // 90% of the amount will be burned
    let mut fee_amount = (10.0 * stake_amount) / 100.0; // 10% will be the fee
    stake_amount = stake_amount - fee_amount;
    amount = amount * (LAMPORTS_PER_SOL as f64);
    fee_amount = fee_amount * (LAMPORTS_PER_SOL as f64);
    let burn_amount = amount as u64;
    let t = fee_amount as u64;

    // Burn the staked amount (90%)
    token::burn(ctx.accounts.burn_context().with_signer(signer_seeds), burn_amount)?;
    msg!("Token burned successfully: {} tokens.", (burn_amount as f64) / (LAMPORTS_PER_SOL as f64));

    // // Transfer the fee (10%) to the treasury wallet
    token::transfer_checked(
        ctx.accounts.transfer_token_to_treasury_wallet_token_ata(),
        t,
        ctx.accounts.mint_account.decimals
    )?;
    msg!("Fee transferred successfully: {} tokens.", (t as f64) / (LAMPORTS_PER_SOL as f64));

    // Now, stake the remaining amount and log the timestamp
    let  current_timestamp = Clock::get()?.unix_timestamp as u64;
    let apy_rate = ctx.accounts.reward_account.apy_rate;
    let apy_time_stamp = ctx.accounts.reward_account.apy_time_stamp;
    let previous_apy_rewards = ctx.accounts.reward_account.previous_apy_rewards;

    // Calculate APY per second
    let seconds_per_year: u64 = 365 * 86400; // Total seconds in a year
    let per_second_apy_rate = apy_rate / (100.0 * (seconds_per_year as f64)); // APY per second

    // Update user negative rewards if not set yet
    if ctx.accounts.user_account.neg_rewards == 0.0 { 
        let time_diff = current_timestamp - apy_time_stamp;
        let neg_rewards = per_second_apy_rate * (time_diff as f64) + previous_apy_rewards;
        ctx.accounts.user_account.neg_rewards = neg_rewards;
        msg!(
            "user stake amount: {}, user staking time: {}, user neg rewards: {}",
            stake_amount,
            current_timestamp,
            neg_rewards
        );
    }

    // Calculate rewards for the user's existing stake
    if ctx.accounts.user_account.stake_amount != 0.0 { 
        let mut time_diff = current_timestamp - apy_time_stamp;
        let mut flag = false;
        if time_diff > current_timestamp - ctx.accounts.user_account.stake_time_stamp {
            time_diff = current_timestamp - ctx.accounts.user_account.stake_time_stamp;
            flag = true;
        }
        let mut new_rewards =
            per_second_apy_rate *
                (ctx.accounts.user_account.stake_amount as f64) *
                (time_diff as f64) +
            previous_apy_rewards * (ctx.accounts.user_account.stake_amount as f64);

        if flag {
            msg!("time_diff: {}", time_diff);
            new_rewards =
                ctx.accounts.user_account.calculated_rewards +
                per_second_apy_rate *
                    (ctx.accounts.user_account.stake_amount as f64) *
                    (time_diff as f64);
            msg!("flag : {}", flag);
        }
        ctx.accounts.user_account.calculated_rewards += new_rewards;
    }

    // Update user stake and timestamp
    ctx.accounts.user_account.stake_amount += stake_amount;
    ctx.accounts.user_account.stake_time_stamp = current_timestamp;

    // If the user is referred, set the level based on the referral chain
    if let Some(referred_code) = args.referred_code {
        // Set the referred code
        ctx.accounts.user_account.referred_code = referred_code;
        msg!("Jai");
    }

    let referrer_seed = derive_referrer_seed(&args, &ctx.accounts.user_account);

    // Fetch and validate the referrer account if a referred code is provided
    let referrer_account = if let Some(referrer_account) = &mut ctx.accounts.referrer_account {
        // Derive the expected PDA for validation
        let (expected_pda, _bump) = Pubkey::find_program_address(
            &[USER_SEED, referrer_seed.as_ref()],
            &ctx.program_id
        );
        msg!("Shree");

        // Validate that the provided account matches the derived PDA
        if referrer_account.key() != expected_pda {
            return Err(StakeProgramError::InvalidReferralInfo.into());
        }
        Some(referrer_account)
    } else {
        None
    };


    if let Some(referrer_account) = referrer_account {
        let referrer_level = referrer_account.level; // Fetch the referrer’s level
        msg!("referrer level:{}", referrer_level);
        if referrer_level > 0 && referrer_level <= 7 {
            let referrer_wallet = referrer_account.wallet_address; // Get the referrer’s wallet address

            // Calculate referral rewards
            let reward_percentage = LEVEL_PERCENTAGES[(referrer_level as usize) - 1];
            let mut reward_amount = (stake_amount * (reward_percentage as f64)) / 100.0;

            msg!(
                "Referrer level {} & its percentage rewards: {}",
                referrer_level,
                reward_percentage
            );

            // Verify the referrer's associated token account (ATA)
            let referrer_ata_pubkey = anchor_spl::associated_token::get_associated_token_address(
                &referrer_wallet,
                &ctx.accounts.mint_account.key()
            );
            msg!("Referrer Token ATA: {}", referrer_ata_pubkey);

            if referrer_ata_pubkey != ctx.accounts.referrer_token_ata.as_ref().unwrap().key() {
                return Err(StakeProgramError::InvalidReferralInfo.into());
            }
            reward_amount = reward_amount * (LAMPORTS_PER_SOL as f64);
            let a = reward_amount as u64;
            // Calculate rewards and fee distribution

            let mut reward = (a * 90) / 100;
            let fee = (a * 10) / 100;

            let staking_fee_account = &mut ctx.accounts.staking_fee_account;
            if staking_fee_account.staking_fee > 0.0 {
                let r = ((a as f64) * staking_fee_account.staking_fee) / 100.0;
                reward = reward - (r as u64);
                let etf = r as u64;
                token::mint_to(
                    CpiContext::new(ctx.accounts.token_program.to_account_info(), MintTo {
                        mint: ctx.accounts.mint_account.to_account_info(),
                        to: ctx.accounts.treasury_wallet_token_ata.to_account_info(),
                        authority: ctx.accounts.mint_account.to_account_info(),
                    }).with_signer(signer_seeds),
                    etf
                )?;

                msg!(
                    "Extra team fee applied with amount: {}",
                    (etf as f64) / (LAMPORTS_PER_SOL as f64)
                );
            }

            msg!(
                "Reward amount: {} Actual rewards: {} & fee: {}",
                reward_amount / (LAMPORTS_PER_SOL as f64),
                (reward as f64) / (LAMPORTS_PER_SOL as f64),
                (fee as f64) / (LAMPORTS_PER_SOL as f64)
            );

            // Mint the 90% referral reward to the referrer’s ATA
            token::mint_to(
                CpiContext::new(ctx.accounts.token_program.to_account_info(), MintTo {
                    mint: ctx.accounts.mint_account.to_account_info(),
                    to: ctx.accounts.referrer_token_ata.as_ref().unwrap().to_account_info(),
                    authority: ctx.accounts.mint_account.to_account_info(),
                }).with_signer(signer_seeds),
                reward
            )?;
            msg!(
                "Minted {} tokens to referrer {} at level {}",
                reward,
                referrer_wallet,
                referrer_level
            );

            // 10% of referral rewards go to the treasury wallet
            token::mint_to(
                CpiContext::new(ctx.accounts.token_program.to_account_info(), MintTo {
                    mint: ctx.accounts.mint_account.to_account_info(),
                    to: ctx.accounts.treasury_wallet_token_ata.to_account_info(),
                    authority: ctx.accounts.mint_account.to_account_info(),
                }).with_signer(signer_seeds),
                fee
            )?;
            msg!(
                "10% of reward goes to treasury wallet, fee: {}",
                (fee as f64) / (LAMPORTS_PER_SOL as f64)
            );

            // Store the referral rewards in the referrer account
            referrer_account.referral_rewards += reward_amount / (LAMPORTS_PER_SOL as f64);
            msg!("Updated referral rewards for referrer: {}", referrer_account.referral_rewards);
        }
    } else {
        msg!("No valid referrer, no rewards distributed.");
    }

    Ok(())
}

#[derive(Accounts)]
#[instruction(args: ArgsStake)]
pub struct Stake<'info> {
    #[account(mut)]
    pub payer: Signer<'info>,

    #[account(
        init_if_needed,
        seeds = [USER_SEED, payer.key().as_ref()],
        bump,
        payer = payer,
        space = 8 + UserAccount::INIT_SPACE
    )]
    pub user_account: Box<Account<'info, UserAccount>>,

    #[account(
        mut,
        seeds = [MINT_PDA_SEED],
        bump,
    )]
    pub mint_account: Account<'info, Mint>,

    #[account(
        init_if_needed,
        payer = payer,
        associated_token::mint = mint_account,
        associated_token::authority = payer
    )]
    pub user_token_ata: Box<Account<'info, TokenAccount>>,
    #[account(mut)]
    pub treasury_wallet_token_ata: Box<Account<'info, TokenAccount>>,

    // Optionally fetch the referred user's referral state
    #[account(
        mut,
    )]
    pub referrer_account: Option<Account<'info, UserAccount>>,

    #[account(mut)]
    pub referrer_token_ata: Option<Account<'info, TokenAccount>>,

    #[account( 
        mut,
        seeds = [APY_REWARDS_SEED],
        bump =  reward_account.bump,
    )]
    pub reward_account: Box<Account<'info, RewardAccount>>,

    #[account( 
        mut,
        seeds = [STAKE_FEE_SEED],
        bump = staking_fee_account.bump
    )]
    pub staking_fee_account: Box<Account<'info, StakingFeeAccount>>,

    pub token_program: Program<'info, Token>,
    pub associated_token_program: Program<'info, AssociatedToken>,
    pub system_program: Program<'info, System>,
    pub rent: Sysvar<'info, Rent>,
}

impl<'info> Stake<'info> {
    pub fn transfer_token_to_treasury_wallet_token_ata(
        &self
    ) -> CpiContext<'_, '_, '_, 'info, TransferChecked<'info>> {
        let cpi_accounts = TransferChecked {
            from: self.user_token_ata.to_account_info(),
            mint: self.mint_account.to_account_info(),
            to: self.treasury_wallet_token_ata.to_account_info(),
            authority: self.payer.to_account_info(),
        };
        CpiContext::new(self.token_program.to_account_info(), cpi_accounts)
    }

    pub fn burn_context(&self) -> CpiContext<'_, '_, '_, 'info, Burn<'info>> {
        let cpi_accounts = Burn {
            mint: self.mint_account.to_account_info(),
            from: self.user_token_ata.to_account_info(),
            authority: self.payer.to_account_info(),
        };
        CpiContext::new(self.token_program.to_account_info(), cpi_accounts)
    }
}

// Before invoking the handler, derive the appropriate referrer seed
fn derive_referrer_seed(args: &ArgsStake, user_account: &Account<UserAccount>) -> Pubkey {
    args.referred_code.unwrap_or(user_account.referred_code)
}

// stake = [{500, 8 oct 10 AM}]
// APY = [{110%, 5 Oct 4PM},{200% 6 Oct 1PM },{100%, 8 oct 11AM}, {70%, 8oct 1PM}, {80%,  9 Oct 5PM }, {120%, 10 Oct 8AM}]
// and if current time is 10 oct 11PM

// so reward = 200% of 500(because from 6 oct 1PM to 8 oct 10:59AM )/365(Because this APY (Annual Price Yeild)) +
// 100% of 500(because from 8 oct 11:00AM to 8 oct 12:59PM )/365(Because this APY (Annual Price Yeild)) + 70% of 500(because from 8 oct 1PM to 9 oct 4:59 PM)/365(Because this APY (Annual Price Yeild))
// + 80% of 500(because from 9 oct 5PM to 10 oct 7:59 AM)/365(Because this APY (Annual Price Yeild)) + 120% of 500(because from 10oct 8AM to current time )/365(Because this APY (Annual Price Yeild))
