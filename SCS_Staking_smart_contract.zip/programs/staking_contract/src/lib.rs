use anchor_lang::prelude::*;

pub mod constant;
pub mod error;
pub mod state;
pub mod event;
pub mod processor;
use crate::processor::*;

declare_id!("CezLs9Rr6BsVxL7xgAtC4ZZK1yrgg8Ye6ceVeQEFcAz3");

#[program]
pub mod staking_contract {
    use super::*;

    pub fn initialize(ctx: Context<Initialize>) -> Result<()> {
        initialize::initialize_handler(ctx)
    }
    pub fn referral_code(ctx: Context<Referral>, args: Args) -> Result<()> {
        referral_code::generate_referral_code(ctx, args)
    }

    pub fn create_token(ctx: Context<CreateToken>, args: CreateTokenArgs) -> Result<()> {
        create_token::create_token(ctx, args)
    }

    pub fn mint_token(ctx: Context<MintToken>, amount: u64) -> Result<()> {
        mint_token::mint_token(ctx, amount)
    }

    pub fn apy(ctx: Context<RewardAPY>, reward_rate: f64) -> Result<()> {
        apy::apy_handler(ctx, reward_rate)
    }

    pub fn create_stake(ctx: Context<Stake>, args: ArgsStake) -> Result<()> {
        create_stake::stake_handler(ctx, args)
    }


    pub fn withdraw_rewards(ctx: Context<RewardsStruct>) -> Result<()> {
        withdraw_rewards::reward_handler(ctx)
    }
    pub fn staking_fee(ctx: Context<StakingFee>, fee: f64) -> Result<()> {
        staking_fee::staking_fee_handler(ctx, fee)
    }
}
