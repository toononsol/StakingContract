const { Connection, PublicKey, clusterApiUrl } = require("@solana/web3.js");
const BN = require("bn.js");
const bs58 = require("bs58");

const PROGRAM_ID = new PublicKey("j3BJjYGFwXLRfz8VS1rm4HYNBWmdg1kEPCRu6atQmif");

// Initialize a connection to Solana Devnet
const connection = new Connection(clusterApiUrl("devnet"));

(async () => {
  try {
    // Derive the PDA for the "Presale" account
    const [presaleAccountPDA] = PublicKey.findProgramAddressSync(
      [Buffer.from("Presale")],
      PROGRAM_ID
    );

    console.log("Presale Account PDA:", presaleAccountPDA.toString());

    // Fetch the raw account data
    const accountInfo = await connection.getAccountInfo(presaleAccountPDA);

    if (accountInfo === null) {
      console.log("Account not found or empty.");
      return;
    }
    console.log(1)

    // Decode the raw data according to the Rust struct layout
    const data = bs58.decode(accountInfo.data);
    console.log(data);
    // const presaleAccount = {
    //   authority: new PublicKey(data.slice(0, 32)),
    //   start_time: new BN(data.slice(32, 40), "le").toNumber(),
    //   end_time: new BN(data.slice(40, 48), "le").toNumber(),
    //   minimum_buyable_amount: new BN(data.slice(48, 56), "le").toNumber(),
    //   maximum_buyable_amount: new BN(data.slice(56, 64), "le").toNumber(),
    //   token_price_in_lamports: new BN(data.slice(64, 72), "le").toNumber(),
    //   total_tokens: new BN(data.slice(72, 80), "le").toNumber(),
    //   is_presale_ended: data[80] === 1,
    //   bump: data[81],
    // };

    // console.log("Decoded Presale Account Data:", presaleAccount);
  } catch (error) {
    console.error("Error fetching presale account data:", error);
  }
})();
