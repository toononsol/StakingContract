import * as anchor from "@coral-xyz/anchor";
import { Program } from "@coral-xyz/anchor";
import { StakingContract } from "../target/types/staking_contract";
import {
  getAssociatedTokenAddressSync,
  TOKEN_2022_PROGRAM_ID,
  ASSOCIATED_TOKEN_PROGRAM_ID,
  getAssociatedTokenAddress,
} from "@solana/spl-token";
import {
  PublicKey,
  LAMPORTS_PER_SOL,
  Keypair,
  Transaction,
  sendAndConfirmTransaction,
  SystemProgram,
} from "@solana/web3.js";
import base58 from "bs58";

describe("staking_contract", () => {
  // Configure the client to use the local cluster.
  const provider = anchor.AnchorProvider.env();
  anchor.setProvider(provider);
  const connection = provider.connection;
  const program = anchor.workspace.StakingContract as Program<StakingContract>;

  const payer = Keypair.fromSecretKey(
    base58.decode(
      " "
    )
  );
  const payer2 = Keypair.fromSecretKey(
    base58.decode(
      " "
    )
  );
  // const payer3 = Keypair.fromSecretKey(base58.decode(""));

  // const payer4 = Keypair.fromSecretKey(base58.decode(""));
  // const payer5 = Keypair.fromSecretKey(base58.decode(""));
  const treasury = Keypair.fromSecretKey(
    base58.decode(
      " "
    )
  );

  // const payer6 = Keypair.fromSecretKey(base58.decode(""));

  // const payer7 = Keypair.fromSecretKey(base58.decode(""));

  // const payer8 = Keypair.fromSecretKey(base58.decode(""));

  const payer9 = Keypair.fromSecretKey(base58.decode(""));

  const USER_SEED = "USER";
  const REFERRED_SEED = "REFERRED_SEED";
  const METADATA_SEED = "metadata";
  const MINT_SEED = "mint";
  const TOKEN_METADATA_PROGRAM_ID = new PublicKey(
    "metaqbxxUerdq28cj1RbAWkYQm3ybzjb6a8bt518x1s"
  );
  const metadata = {
    name: "The Toocinator",
    symbol: "Toon",
    uri: "https://pink-rare-giraffe-95.mypinata.cloud/ipfs/QmdS8fzXLMj5guztkombrHcdTyab2TfxcJ3F8XgGp7idMb",
    decimals: 9,
  };
  let treasuryAssociatedTokenAccountAddress;
  let associatedTokenAccountAddress;
  let associatedTokenAccountAddress2;
  let associatedTokenAccountAddress3;
  let associatedTokenAccountAddress4;
  let associatedTokenAccountAddress9;
  // let referredCode = payer.publicKey;
  const mintAmount = new anchor.BN(10);
  const stakeAmount = 100.0;
  const burnAmount = new anchor.BN(10 * LAMPORTS_PER_SOL);
  let rewardRate = 180.0;
  const [mint] = PublicKey.findProgramAddressSync(
    [Buffer.from(MINT_SEED)],
    program.programId
  );

  const [metadataAddress] = PublicKey.findProgramAddressSync(
    [
      Buffer.from(METADATA_SEED),
      TOKEN_METADATA_PROGRAM_ID.toBuffer(),
      mint.toBuffer(),
    ],
    TOKEN_METADATA_PROGRAM_ID
  );

  // const [userPda] = PublicKey.findProgramAddressSync(
  //   [Buffer.from(USER_SEED), payer.publicKey.toBuffer()],
  //   program.programId
  // );

  // const [user2Pda] = PublicKey.findProgramAddressSync(
  //   [Buffer.from(USER_SEED), payer2.publicKey.toBuffer()],
  //   program.programId
  // );

  // const [user3Pda] = PublicKey.findProgramAddressSync(
  //   [Buffer.from(USER_SEED), payer3.publicKey.toBuffer()],
  //   program.programId
  // );
  // const [user4Pda] = PublicKey.findProgramAddressSync(
  //   [Buffer.from(USER_SEED), payer4.publicKey.toBuffer()],
  //   program.programId
  // );

  // const [user5Pda] = PublicKey.findProgramAddressSync(
  //   [Buffer.from(USER_SEED), payer5.publicKey.toBuffer()],
  //   program.programId
  // );
  // const [user6Pda] = PublicKey.findProgramAddressSync(
  //   [Buffer.from(USER_SEED), payer6.publicKey.toBuffer()],
  //   program.programId
  // );
  // const [user7Pda] = PublicKey.findProgramAddressSync(
  //   [Buffer.from(USER_SEED), payer7.publicKey.toBuffer()],
  //   program.programId
  // );
  // const [user8Pda] = PublicKey.findProgramAddressSync(
  //   [Buffer.from(USER_SEED), payer8.publicKey.toBuffer()],
  //   program.programId
  // );
  // const [user9Pda] = PublicKey.findProgramAddressSync(
  //   [Buffer.from(USER_SEED), payer9.publicKey.toBuffer()],
  //   program.programId
  // );

  // const [referredPDA] = PublicKey.findProgramAddressSync(
  //   [Buffer.from(REFERRED_SEED), referredCode.toBuffer()],
  //   program.programId
  // );

  async function airdrop(receiver: PublicKey) {
    await new Promise((resolve) => setTimeout(resolve, 1000));

    console.log("Airdropping SOL to:", receiver.toBase58());
    const airdropSignature = await connection.requestAirdrop(
      receiver,
      5 * LAMPORTS_PER_SOL
    );

    const latestBlockhash = await connection.getLatestBlockhash();
    await connection.confirmTransaction({
      signature: airdropSignature,
      blockhash: latestBlockhash.blockhash,
      lastValidBlockHeight: latestBlockhash.lastValidBlockHeight,
    });

    const balance = await connection.getBalance(receiver);
    console.log("Airdrop successful:", airdropSignature);
    console.log("Receiver's Balance:", balance);
  }

  // it("create token", async () => {
  //   try {
  //     // await airdrop(treasury.publicKey);

  //     const createTokenArgs = {
  //       tokenName: metadata.name,
  //       tokenSymbol: metadata.symbol,
  //       tokenUri: metadata.uri,
  //     };

  //     const ix = await program.methods
  //       .createToken(createTokenArgs)
  //       .accounts({
  //         payer: treasury.publicKey,
  //         mintAccount: mint,
  //       })
  //       .instruction();  

  //     const tx = new Transaction();
  //     tx.add(ix);

  //     const signature = await sendAndConfirmTransaction(connection, tx, [
  //       treasury,
  //     ]);
  //     console.log("Token is created", signature);
  //     // const token = await program.account.mintAccount.fetch(mint);

  //     // const rewardAccount = await program.account.rewardAccount.fetch(feePDA);

  //     // console.log("Token", token);
  //   } catch (error) {
  //     console.log(error);
  //     throw error;
  //   }
  // });

  // it("Set the APY reward rate for the users", async () => {
  //   try {
  //     const ix = await program.methods
  //       .apy(rewardRate)
  //       .accounts({ payer: treasury.publicKey })
  //       .instruction();

  //     const tx = new Transaction();
  //     tx.add(ix);

  //     const signature = await connection.sendTransaction(tx, [treasury], {
  //       skipPreflight: false,
  //       preflightCommitment: "confirmed", // Set preflight commitment level
  //     });

  //     console.log("Transaction sent with signature:", signature);

  //     // Wait for confirmation
  //     const latestBlockhash = await connection.getLatestBlockhash();
  //     const confirmation = await connection.confirmTransaction(
  //       {
  //         signature,
  //         blockhash: latestBlockhash.blockhash,
  //         lastValidBlockHeight: latestBlockhash.lastValidBlockHeight,
  //       },
  //       "confirmed" // Set the desired confirmation level here
  //     );

  //     if (confirmation.value.err) {
  //       console.error("Transaction failed:", confirmation.value.err);
  //       throw new Error("Transaction failed");
  //     }

  //     console.log("Transaction confirmed successfully");

  //     // Fetch the transaction details using getTransaction
  //     const transactionDetails = await connection.getTransaction(signature, {
  //       commitment: "confirmed",
  //     });

  //     // Display transaction logs
  //     console.log(transactionDetails.meta.logMessages);
  //   } catch (error) {
  //     console.log(error);
  //     throw error;
  //   }
  // });

  // it("Set the extra Staking fee", async () => {
  //   try {
  //     const ix = await program.methods
  //       .stakingFee(20.0)
  //       .accounts({
  //         payer: treasury.publicKey,
  //       })
  //       .instruction();

  //     const tx = new Transaction();
  //     tx.add(ix);

  //     const signature = await connection.sendTransaction(tx, [treasury], {
  //       skipPreflight: false,
  //       preflightCommitment: "confirmed", // Set preflight commitment level
  //     });

  //     console.log("Transaction sent with signature:", signature);

  //     // Wait for confirmation
  //     const latestBlockhash = await connection.getLatestBlockhash();
  //     const confirmation = await connection.confirmTransaction(
  //       {
  //         signature,
  //         blockhash: latestBlockhash.blockhash,
  //         lastValidBlockHeight: latestBlockhash.lastValidBlockHeight,
  //       },
  //       "confirmed" // Set the desired confirmation level here
  //     );

  //     if (confirmation.value.err) {
  //       console.error("Transaction failed:", confirmation.value.err);
  //       throw new Error("Transaction failed");
  //     }

  //     console.log("Transaction confirmed successfully");

  //     // Fetch the transaction details using getTransaction
  //     const transactionDetails = await connection.getTransaction(signature, {
  //       commitment: "confirmed",
  //     });

  //     // Display transaction logs
  //     console.log(transactionDetails.meta.logMessages);
  //   } catch (error) {
  //     console.log(error);
  //     throw error;
  //   }
  // });
  // it("create ATA via initiazation, for treasury wallet ", async () => {
  //   try {
  //     // await airdrop(treasury.publicKey);

  //     treasuryAssociatedTokenAccountAddress = getAssociatedTokenAddressSync(
  //       mint,
  //       treasury.publicKey
  //     );
  //     const ix = await program.methods
  //       .initialize()
  //       .accounts({
  //         payer: treasury.publicKey,
  //       })
  //       .instruction();

  //     const tx = new Transaction();
  //     tx.add(ix);

  //     const signature = await sendAndConfirmTransaction(connection, tx, [
  //       treasury,
  //     ]);
  //     console.log("Token ATA for  treasury wallet initiated", signature);
  //   } catch (error) {
  //     console.log(error);
  //   }
  // });
  // it("mint the token to treasury", async () => {
  //   try {
  //     treasuryAssociatedTokenAccountAddress =
  //       await getAssociatedTokenAddressSync(mint, treasury.publicKey);
  //     const t = new anchor.BN(100000);
  //     const ix = await program.methods
  //       .mintToken(t)
  //       .accounts({
  //         payer: treasury.publicKey,
  //       })
  //       .instruction();

  //     const tx = new Transaction();
  //     tx.add(ix);

  //     // const signature = await connection.sendTransaction(tx, [treasury], {
  //     //   skipPreflight: false,
  //     //   preflightCommitment: "confirmed", // Set preflight commitment level
  //     // });

  //     // console.log("Transaction sent with signature:", signature);

  //     // Wait for confirmation
  //     // const latestBlockhash = await connection.getLatestBlockhash();
  //     // const confirmation = await connection.confirmTransaction(
  //     //   {
  //     //     signature,
  //     //     blockhash: latestBlockhash.blockhash,
  //     //     lastValidBlockHeight: latestBlockhash.lastValidBlockHeight,
  //     //   },
  //     //   "confirmed" // Set the desired confirmation level here
  //     // );

  //     // if (confirmation.value.err) {
  //     //   console.error("Transaction failed:", confirmation.value.err);
  //     //   throw new Error("Transaction failed");
  //     // }

  //     // console.log("Transaction confirmed successfully");

  //     // // Fetch the transaction details using getTransaction
  //     // const transactionDetails = await connection.getTransaction(signature, {
  //     //   commitment: "confirmed",
  //     // });

  //     // Display transaction logs
  //     // console.log(transactionDetails.meta.logMessages);
  //   } catch (error) {
  //     console.log(error);
  //   }
  // });

  // // it("Register user 1 ", async () => {
  // //   // await airdrop(payer.publicKey);
  // //   try {
  // //     referredCode = null;
  // //     const ix = await program.methods
  // //       .userRegister({ referredCode })
  // //       .accounts({
  // //         payer: payer.publicKey,
  // //         referrerAccount: null,
  // //       })
  // //       .instruction();
  // //     const tx = new Transaction();
  // //     tx.add(ix);

  // //     const signature = await connection.sendTransaction(tx, [payer], {
  // //       skipPreflight: false,
  // //       preflightCommitment: "confirmed", // Set preflight commitment level
  // //     });

  // //     console.log("Transaction sent with signature:", signature);

  // //     // Wait for confirmation
  // //     const latestBlockhash = await connection.getLatestBlockhash();
  // //     const confirmation = await connection.confirmTransaction(
  // //       {
  // //         signature,
  // //         blockhash: latestBlockhash.blockhash,
  // //         lastValidBlockHeight: latestBlockhash.lastValidBlockHeight,
  // //       },
  // //       "confirmed" // Set the desired confirmation level here
  // //     );

  // //     if (confirmation.value.err) {
  // //       console.error("Transaction failed:", confirmation.value.err);
  // //       throw new Error("Transaction failed");
  // //     }

  // //     console.log("Transaction confirmed successfully");

  // //     // Fetch the transaction details using getTransaction
  // //     const transactionDetails = await connection.getTransaction(signature, {
  // //       commitment: "confirmed",
  // //     });

  // //     // Display transaction logs
  // //     console.log(transactionDetails.meta.logMessages);
  // //   } catch (error) {
  // //     console.log(error);
  // //     throw error;
  // //   }
  // // });

  // it("mint the token to user 1", async () => {
  //   try {
  //     associatedTokenAccountAddress = await getAssociatedTokenAddressSync(
  //       mint,
  //       payer.publicKey
  //     );
  //     const t = new anchor.BN(200);
  //     const ix = await program.methods
  //       .mint(t)
  //       .accounts({
  //         payer: payer.publicKey,
  //       })
  //       .instruction();

  //     const tx = new Transaction();
  //     tx.add(ix);

  //     const signature = await connection.sendTransaction(tx, [payer], {
  //       skipPreflight: false,
  //       preflightCommitment: "confirmed", // Set preflight commitment level
  //     });

  //     console.log("Transaction sent with signature:", signature);

  //     // Wait for confirmation
  //     const latestBlockhash = await connection.getLatestBlockhash();
  //     const confirmation = await connection.confirmTransaction(
  //       {
  //         signature,
  //         blockhash: latestBlockhash.blockhash,
  //         lastValidBlockHeight: latestBlockhash.lastValidBlockHeight,
  //       },
  //       "confirmed" // Set the desired confirmation level here
  //     );

  //     if (confirmation.value.err) {
  //       console.error("Transaction failed:", confirmation.value.err);
  //       throw new Error("Transaction failed");
  //     }

  //     console.log("Transaction confirmed successfully");

  //     // Fetch the transaction details using getTransaction
  //     const transactionDetails = await connection.getTransaction(signature, {
  //       commitment: "confirmed",
  //     });

  //     // Display transaction logs
  //     // console.log(transactionDetails.meta.logMessages);
  //   } catch (error) {
  //     console.log(error);
  //   }
  // });

  // it("User 1 stake the token", async () => {
  //   try {
  //     let token = new PublicKey("5VMif4XGRbvdtG8GVjDm14cUuUtVFmNC3ZDD1VFSrn8F");

  //     associatedTokenAccountAddress = await getAssociatedTokenAddressSync(
  //       token,
  //       payer.publicKey
  //     );
  //     treasuryAssociatedTokenAccountAddress =
  //       await getAssociatedTokenAddressSync(token, treasury.publicKey);

  //     const accounts = {
  //       payer: payer.publicKey,
  //       userTokenAta: associatedTokenAccountAddress,
  //       treasuryWalletTokenAta: treasuryAssociatedTokenAccountAddress,
  //       referrerAccount: null,
  //       referrerTokenAta: null,
  //     };
  //     const ArgsStake = {
  //       referredCode: null,
  //       stakeAmount: stakeAmount,
  //     };
  //     const ix = await program.methods
  //       .createStake(ArgsStake)
  //       .accounts(accounts)
  //       .instruction();

  //     const tx = new Transaction();
  //     tx.add(ix);

  //     const signature = await connection.sendTransaction(tx, [payer], {
  //       skipPreflight: false,
  //       preflightCommitment: "confirmed", // Set preflight commitment level
  //     });

  //     console.log("Transaction sent with signature:", signature);

  //     // Wait for confirmation
  //     const latestBlockhash = await connection.getLatestBlockhash();
  //     const confirmation = await connection.confirmTransaction(
  //       {
  //         signature,
  //         blockhash: latestBlockhash.blockhash,
  //         lastValidBlockHeight: latestBlockhash.lastValidBlockHeight,
  //       },
  //       "confirmed" // Set the desired confirmation level here
  //     );

  //     if (confirmation.value.err) {
  //       console.error("Transaction failed:", confirmation.value.err);
  //       throw new Error("Transaction failed");
  //     }

  //     console.log("Transaction confirmed successfully");

  //     // Fetch the transaction details using getTransaction
  //     const transactionDetails = await connection.getTransaction(signature, {
  //       commitment: "confirmed",
  //     });

  //     // Display transaction logs
  //     console.log(transactionDetails.meta.logMessages);
  //     await new Promise((resolve) => setTimeout(resolve, 1000));
  //   } catch (error) {
  //     console.log(error);
  //     throw error;
  //   }
  // });

  // it("Show the reward for user 1", async () => {
  //   try {
  //     let SEED = "APY_REWARDS_SEED";
  //     const [feePDA] = PublicKey.findProgramAddressSync(
  //       [Buffer.from(SEED)],
  //       program.programId
  //     );
  // const rewardAccount = await program.account.rewardAccount.fetch(feePDA);
  //     console.log("rewardAccount", rewardAccount);

  //     const timestampInSeconds = rewardAccount.apyTimeStamp.toNumber(); // Assuming apyTimeStamp is a BN object
  //     const date = new Date(timestampInSeconds * 1000);
  //     console.log("APY Time in Local Timezone:", date.toLocaleString());

  //     await new Promise((resolve) => setTimeout(resolve, 1000));
  //     const ix = await program.methods
  //       .showRewards()
  //       .accounts({
  //         payer: payer.publicKey,
  //       })
  //       .instruction();

  //     const tx = new Transaction();
  //     tx.add(ix);

  //     const signature = await connection.sendTransaction(tx, [payer], {
  //       skipPreflight: false,
  //       preflightCommitment: "confirmed", // Set preflight commitment level
  //     });

  //     console.log("Transaction sent with signature:", signature);

  //     // Wait for confirmation
  //     const latestBlockhash = await connection.getLatestBlockhash();
  //     const confirmation = await connection.confirmTransaction(
  //       {
  //         signature,
  //         blockhash: latestBlockhash.blockhash,
  //         lastValidBlockHeight: latestBlockhash.lastValidBlockHeight,
  //       },
  //       "confirmed" // Set the desired confirmation level here
  //     );

  //     if (confirmation.value.err) {
  //       console.error("Transaction failed:", confirmation.value.err);
  //       throw new Error("Transaction failed");
  //     }

  //     console.log("Transaction confirmed successfully");

  //     // Fetch the transaction details using getTransaction
  //     const transactionDetails = await connection.getTransaction(signature, {
  //       commitment: "confirmed",
  //     });

  //     // Display transaction logs
  //     console.log(transactionDetails.meta.logMessages);
  //   } catch (error) {
  //     console.log(error);
  //     throw error;
  //   }
  // });

  // it("user 1 generate referral code", async () => {
  //   try {
  //     const Args = {
  //       referredCode: null,
  //     };
  //     const ix = await program.methods
  //       .referralCode(Args)
  //       .accounts({
  //         payer: payer.publicKey,
  //         referredState: null,
  //         referrerAccount: null,
  //       })
  //       .instruction();

  //     const tx = new Transaction();
  //     tx.add(ix);
  //     // const signature = await sendAndConfirmTransaction(connection, tx, [
  //     //   treasury,
  //     // ]);
  //     // console.log("referral  code is created", signature);

  //     const signature = await connection.sendTransaction(tx, [payer], {
  //       skipPreflight: false,
  //       preflightCommitment: "confirmed", // Set preflight commitment level
  //     });

  //     console.log("Transaction sent with signature:", signature);

  //     // Wait for confirmation
  //     const latestBlockhash = await connection.getLatestBlockhash();
  //     const confirmation = await connection.confirmTransaction(
  //       {
  //         signature,
  //         blockhash: latestBlockhash.blockhash,
  //         lastValidBlockHeight: latestBlockhash.lastValidBlockHeight,
  //       },
  //       "confirmed" // Set the desired confirmation level here
  //     );

  //     if (confirmation.value.err) {
  //       console.error("Transaction failed:", confirmation.value.err);
  //       throw new Error("Transaction failed");
  //     }

  //     console.log("Transaction confirmed successfully");

  //     // Fetch the transaction details using getTransaction
  //     const transactionDetails = await connection.getTransaction(signature, {
  //       commitment: "confirmed",
  //     });

  //     // Display transaction logs
  //     console.log(transactionDetails.meta.logMessages);
  //   } catch (error) {
  //     console.log(error);
  //     throw error;
  //   }
  // });

  // // it("User 2 registered with referral code  of user 1", async () => {
  // //   try {
  // //     await airdrop(payer2.publicKey);

  // //     referredCode = payer.publicKey;
  // //     const [correctReferredPDA] = PublicKey.findProgramAddressSync(
  // //       [Buffer.from(USER_SEED), referredCode.toBuffer()],
  // //       program.programId
  // //     );

  // //     const ix = await program.methods
  // //       .userRegister({ referredCode })
  // //       .accounts({
  // //         payer: payer2.publicKey,
  // //         referrerAccount: correctReferredPDA,
  // //       })
  // //       .instruction();

  // //     const tx = new Transaction();
  // //     tx.add(ix);

  // //     const signature = await connection.sendTransaction(tx, [payer2], {
  // //       skipPreflight: false,
  // //       preflightCommitment: "confirmed", // Set preflight commitment level
  // //     });

  // //     console.log("Transaction sent with signature:", signature);

  // //     // Wait for confirmation
  // //     const latestBlockhash = await connection.getLatestBlockhash();
  // //     const confirmation = await connection.confirmTransaction(
  // //       {
  // //         signature,
  // //         blockhash: latestBlockhash.blockhash,
  // //         lastValidBlockHeight: latestBlockhash.lastValidBlockHeight,
  // //       },
  // //       "confirmed" // Set the desired confirmation level here
  // //     );

  // //     if (confirmation.value.err) {
  // //       console.error("Transaction failed:", confirmation.value.err);
  // //       throw new Error("Transaction failed");
  // //     }

  // //     console.log("Transaction confirmed successfully");

  // //     // Fetch the transaction details using getTransaction
  // //     const transactionDetails = await connection.getTransaction(signature, {
  // //       commitment: "confirmed",
  // //     });

  // //     console.log(transactionDetails.meta.logMessages);
  // //   } catch (error) {
  // //     console.log(error);
  // //     throw error;
  // //   }
  // // });

  // it("mint the token to user 2", async () => {
  //   await airdrop(payer2.publicKey);
  //   try {
  //     associatedTokenAccountAddress2 = getAssociatedTokenAddressSync(
  //       mint,
  //       payer2.publicKey
  //     );

  //     const ix = await program.methods
  //       .mint(mintAmount)
  //       .accounts({
  //         payer: payer2.publicKey,
  //       })
  //       .instruction();

  //     const tx = new Transaction();
  //     tx.add(ix);

  //     const signature = await connection.sendTransaction(tx, [payer2], {
  //       skipPreflight: false,
  //       preflightCommitment: "confirmed", // Set preflight commitment level
  //     });

  //     console.log("Transaction sent with signature:", signature);

  //     // Wait for confirmation
  //     const latestBlockhash = await connection.getLatestBlockhash();
  //     const confirmation = await connection.confirmTransaction(
  //       {
  //         signature,
  //         blockhash: latestBlockhash.blockhash,
  //         lastValidBlockHeight: latestBlockhash.lastValidBlockHeight,
  //       },
  //       "confirmed" // Set the desired confirmation level here
  //     );

  //     if (confirmation.value.err) {
  //       console.error("Transaction failed:", confirmation.value.err);
  //       throw new Error("Transaction failed");
  //     }

  //     console.log("Transaction confirmed successfully");

  //     // Fetch the transaction details using getTransaction
  //     const transactionDetails = await connection.getTransaction(signature, {
  //       commitment: "confirmed",
  //     });

  //     // Display transaction logs
  //     console.log(transactionDetails.meta.logMessages);
  //   } catch (error) {
  //     console.log(error);
  //   }
  // });

  // it("user 2 staking the token", async () => {
  //   try {
  //     let token = new PublicKey("5VMif4XGRbvdtG8GVjDm14cUuUtVFmNC3ZDD1VFSrn8F")
  //     associatedTokenAccountAddress2 = getAssociatedTokenAddressSync(
  //       token,
  //       payer2.publicKey
  //     );
  //     treasuryAssociatedTokenAccountAddress = getAssociatedTokenAddressSync(
  //       token,
  //       treasury.publicKey
  //     );

  //     // const userAccount = await program.account.userAccount.fetch(user2Pda);
  //     // console.log(userAccount);

  //     let referredCode = payer.publicKey;
  //     const [correctReferredPDA] = PublicKey.findProgramAddressSync(
  //       [Buffer.from(USER_SEED), referredCode.toBuffer()],
  //       program.programId
  //     );

  //     // Find the associated token account for the last referrer
  //     let referrerAssociatedTokenAccountAddress = getAssociatedTokenAddressSync(
  //       token,
  //       referredCode
  //     );

  //     const accounts = {
  //       payer: payer2.publicKey,
  //       userTokenAta: associatedTokenAccountAddress2,
  //       treasuryWalletTokenAta: treasuryAssociatedTokenAccountAddress,
  //       referrerAccount: correctReferredPDA,
  //       referrerTokenAta: referrerAssociatedTokenAccountAddress,
  //     };

  //     const ArgsStake = {
  //       referredCode: referredCode,
  //       stakeAmount: stakeAmount,
  //     };

  //     const ix = await program.methods
  //       .createStake(ArgsStake)
  //       .accounts(accounts)
  //       .instruction();

  //     const tx = new Transaction();
  //     tx.add(ix);

  //     const signature = await connection.sendTransaction(tx, [payer2], {
  //       skipPreflight: false,
  //       preflightCommitment: "confirmed", // Set preflight commitment level
  //     });

  //     console.log("Transaction sent with signature:", signature);

  //     // Wait for confirmation
  //     const latestBlockhash = await connection.getLatestBlockhash();
  //     const confirmation = await connection.confirmTransaction(
  //       {
  //         signature,
  //         blockhash: latestBlockhash.blockhash,
  //         lastValidBlockHeight: latestBlockhash.lastValidBlockHeight,
  //       },
  //       "confirmed" // Set the desired confirmation level here
  //     );

  //     if (confirmation.value.err) {
  //       console.error("Transaction failed:", confirmation.value.err);
  //       throw new Error("Transaction failed");
  //     }

  //     console.log("Transaction confirmed successfully");

  //     // Fetch the transaction details using getTransaction
  //     const transactionDetails = await connection.getTransaction(signature, {
  //       commitment: "confirmed",
  //     });

  //     // Display transaction logs
  //     console.log(transactionDetails.meta.logMessages);
  //   } catch (error) {
  //     console.log(error);
  //     throw error;
  //   }
  // });

  // it("Show the reward for user 2", async () => {
  //   try {
  //     // await new Promise((resolve) => setTimeout(resolve, 1000));
  //     const ix = await program.methods
  //       .showRewards()
  //       .accounts({
  //         payer: payer2.publicKey,
  //       })
  //       .instruction();

  //     const tx = new Transaction();
  //     tx.add(ix);

  //     const signature = await connection.sendTransaction(tx, [payer2], {
  //       skipPreflight: false,
  //       preflightCommitment: "confirmed", // Set preflight commitment level
  //     });

  //     console.log("Transaction sent with signature:", signature);

  //     // Wait for confirmation
  //     const latestBlockhash = await connection.getLatestBlockhash();
  //     const confirmation = await connection.confirmTransaction(
  //       {
  //         signature,
  //         blockhash: latestBlockhash.blockhash,
  //         lastValidBlockHeight: latestBlockhash.lastValidBlockHeight,
  //       },
  //       "confirmed" // Set the desired confirmation level here
  //     );

  //     if (confirmation.value.err) {
  //       console.error("Transaction failed:", confirmation.value.err);
  //       throw new Error("Transaction failed");
  //     }

  //     console.log("Transaction confirmed successfully");

  //     // Fetch the transaction details using getTransaction
  //     const transactionDetails = await connection.getTransaction(signature, {
  //       commitment: "confirmed",
  //     });

  //     // Display transaction logs
  //     console.log(transactionDetails.meta.logMessages);
  //   } catch (error) {
  //     console.log(error);
  //     throw error;
  //   }
  // });

  // it("user 2 generate referral code", async () => {
  //   try {
  //     const userAccount = await program.account.userAccount.fetch(user2Pda);
  //     let referredCode = new PublicKey(userAccount.referredCode);
      // const [correctReferredPDA] = PublicKey.findProgramAddressSync(
      //   [Buffer.from(REFERRED_SEED), referredCode.toBuffer()],
      //   program.programId
      // );
  //     const [referrerAccountPDA] = PublicKey.findProgramAddressSync(
  //       [Buffer.from(USER_SEED), referredCode.toBuffer()],
  //       program.programId
  //     );

  //     const Args = {
  //       referredCode: null,
  //     };

  //     const ix = await program.methods
  //       .referralCode(Args)
  //       .accounts({
  //         payer: payer2.publicKey,
  //         referredState: correctReferredPDA,
  //         referrerAccount: referrerAccountPDA,
  //       })
  //       .instruction();

  //     const tx = new Transaction();
  //     tx.add(ix);

  //     const signature = await connection.sendTransaction(tx, [payer2], {
  //       skipPreflight: false,
  //       preflightCommitment: "confirmed", // Set preflight commitment level
  //     });

  //     console.log("Transaction sent with signature:", signature);

  //     // Wait for confirmation
  //     const latestBlockhash = await connection.getLatestBlockhash();
  //     const confirmation = await connection.confirmTransaction(
  //       {
  //         signature,
  //         blockhash: latestBlockhash.blockhash,
  //         lastValidBlockHeight: latestBlockhash.lastValidBlockHeight,
  //       },
  //       "confirmed" // Set the desired confirmation level here
  //     );

  //     if (confirmation.value.err) {
  //       console.error("Transaction failed:", confirmation.value.err);
  //       throw new Error("Transaction failed");
  //     }

  //     console.log("Transaction confirmed successfully");

  //     // Fetch the transaction details using getTransaction
  //     const transactionDetails = await connection.getTransaction(signature, {
  //       commitment: "confirmed",
  //     });

  //     // Display transaction logs
  //     console.log(transactionDetails.meta.logMessages);
  //   } catch (error) {
  //     console.log(error);
  //     throw error;
  //   }
  // });

  // // it("User 3 registered with referral code of  user 2 ", async () => {
  // //   try {
  // //     await airdrop(payer3.publicKey);
  // //     let referredCode = payer2.publicKey;
  // //     const [correctReferredPDA] = PublicKey.findProgramAddressSync(
  // //       [Buffer.from(USER_SEED), referredCode.toBuffer()],
  // //       program.programId
  // //     );

  // //     const ix = await program.methods
  // //       .userRegister({ referredCode })
  // //       .accounts({
  // //         payer: payer3.publicKey,
  // //         referrerAccount: correctReferredPDA,
  // //       })
  // //       .instruction();

  // //     const tx = new Transaction();
  // //     tx.add(ix);

  // //     const signature = await connection.sendTransaction(tx, [payer3], {
  // //       skipPreflight: false,
  // //       preflightCommitment: "confirmed", // Set preflight commitment level
  // //     });

  // //     console.log("Transaction sent with signature:", signature);

  // //     // Wait for confirmation
  // //     const latestBlockhash = await connection.getLatestBlockhash();
  // //     const confirmation = await connection.confirmTransaction(
  // //       {
  // //         signature,
  // //         blockhash: latestBlockhash.blockhash,
  // //         lastValidBlockHeight: latestBlockhash.lastValidBlockHeight,
  // //       },
  // //       "confirmed" // Set the desired confirmation level here
  // //     );

  // //     if (confirmation.value.err) {
  // //       console.error("Transaction failed:", confirmation.value.err);
  // //       throw new Error("Transaction failed");
  // //     }

  // //     console.log("Transaction confirmed successfully");

  // //     // Fetch the transaction details using getTransaction
  // //     const transactionDetails = await connection.getTransaction(signature, {
  // //       commitment: "confirmed",
  // //     });

  // //     console.log(transactionDetails.meta.logMessages);

  // //     // const userAccountData = await program.account.userAccount.fetch(user3Pda);
  // //     // console.log("User 3 account data:\n\n", userAccountData,"\n\n");
  // //   } catch (error) {
  // //     console.log(error);
  // //     throw error;
  // //   }
  // // });

  // // // it("mint the token to user 3", async () => {
  // // //   try {
  // // //     associatedTokenAccountAddress3 = getAssociatedTokenAddressSync(
  // // //       mint,
  // // //       payer3.publicKey
  // // //     );

  // // //     const ix = await program.methods
  // // //       .mint(mintAmount)
  // // //       .accounts({
  // // //         payer: payer3.publicKey,
  // // //       })
  // // //       .instruction();

  // // //     const tx = new Transaction();
  // // //     tx.add(ix);

  // // //     const signature = await connection.sendTransaction(tx, [payer3], {
  // // //       skipPreflight: false,
  // // //       preflightCommitment: "confirmed", // Set preflight commitment level
  // // //     });

  // // //     console.log("Transaction sent with signature:", signature);

  // // //     // Wait for confirmation
  // // //     const latestBlockhash = await connection.getLatestBlockhash();
  // // //     const confirmation = await connection.confirmTransaction(
  // // //       {
  // // //         signature,
  // // //         blockhash: latestBlockhash.blockhash,
  // // //         lastValidBlockHeight: latestBlockhash.lastValidBlockHeight,
  // // //       },
  // // //       "confirmed" // Set the desired confirmation level here
  // // //     );

  // // //     if (confirmation.value.err) {
  // // //       console.error("Transaction failed:", confirmation.value.err);
  // // //       throw new Error("Transaction failed");
  // // //     }

  // // //     console.log("Transaction confirmed successfully");

  // // //     // Fetch the transaction details using getTransaction
  // // //     const transactionDetails = await connection.getTransaction(signature, {
  // // //       commitment: "confirmed",
  // // //     });

  // // //     // Display transaction logs
  // // //     console.log(transactionDetails.meta.logMessages);
  // // //   } catch (error) {
  // // //     console.log(error);
  // // //   }
  // // // });

  // it("user 3 generate referral code", async () => {
  //   try {
  //     await airdrop(payer3.publicKey);

  //     let referredCode;

  //     try {
  //       // Try to fetch the user account
  //       const userAccount = await program.account.userAccount.fetch(user3Pda);
  //       console.log("user 3", userAccount.referredCode);
  //       referredCode = new PublicKey(userAccount.referredCode);
  //     } catch (error) {
  //       // If fetching the user account fails, use the alternative
  //       if (error.message.includes("Account does not exist or has no data")) {
  //         console.log("user 3 5678");
  //         referredCode = payer2.publicKey;
  //       } else {
  //         // Re-throw other unexpected errors
  //         throw error;
  //       }
  //     }
  //     const [correctReferredPDA] = PublicKey.findProgramAddressSync(
  //       [Buffer.from(REFERRED_SEED), referredCode.toBuffer()],
  //       program.programId
  //     );
  //     console.log(correctReferredPDA);
  //     const [referrerAccountPDA] = PublicKey.findProgramAddressSync(
  //       [Buffer.from(USER_SEED), referredCode.toBuffer()],
  //       program.programId
  //     );
  //     console.log(referrerAccountPDA);

  //     const Args = {
  //       referredCode: referredCode || null,
  //     };

  //     const ix = await program.methods
  //       .referralCode(Args)
  //       .accounts({
  //         payer: payer3.publicKey,
  //         referredState: correctReferredPDA || null,
  //         referrerAccount: referrerAccountPDA || null,
  //       })
  //       .instruction();

  //     const tx = new Transaction();
  //     tx.add(ix);

  //     const signature = await connection.sendTransaction(tx, [payer3], {
  //       skipPreflight: false,
  //       preflightCommitment: "confirmed", // Set preflight commitment level
  //     });

  //     console.log("Transaction sent with signature:", signature);

  //     // Wait for confirmation
  //     const latestBlockhash = await connection.getLatestBlockhash();
  //     const confirmation = await connection.confirmTransaction(
  //       {
  //         signature,
  //         blockhash: latestBlockhash.blockhash,
  //         lastValidBlockHeight: latestBlockhash.lastValidBlockHeight,
  //       },
  //       "confirmed" // Set the desired confirmation level here
  //     );

  //     if (confirmation.value.err) {
  //       console.error("Transaction failed:", confirmation.value.err);
  //       throw new Error("Transaction failed");
  //     }

  //     console.log("Transaction confirmed successfully");

  //     // Fetch the transaction details using getTransaction
  //     const transactionDetails = await connection.getTransaction(signature, {
  //       commitment: "confirmed",
  //     });

  //     // Display transaction logs
  //     console.log(transactionDetails.meta.logMessages);
  //   } catch (error) {
  //     console.log(error);
  //     throw error;
  //   }
  // });

  // // it("User 4 registered with referral code of user 3", async () => {
  // //   await airdrop(payer4.publicKey);

  // //   try {
  // //     referredCode = payer3.publicKey;
  // //     const [correctReferredPDA] = PublicKey.findProgramAddressSync(
  // //       [Buffer.from(USER_SEED), referredCode.toBuffer()],
  // //       program.programId
  // //     );

  // //     const ix = await program.methods
  // //       .userRegister({ referredCode })
  // //       .accounts({
  // //         payer: payer4.publicKey,
  // //         referrerAccount: correctReferredPDA,
  // //       })
  // //       .instruction();

  // //     const tx = new Transaction();
  // //     tx.add(ix);

  // //     const signature = await connection.sendTransaction(tx, [payer4], {
  // //       skipPreflight: false,
  // //       preflightCommitment: "confirmed", // Set preflight commitment level
  // //     });

  // //     console.log("Transaction sent with signature:", signature);

  // //     // Wait for confirmation
  // //     const latestBlockhash = await connection.getLatestBlockhash();
  // //     const confirmation = await connection.confirmTransaction(
  // //       {
  // //         signature,
  // //         blockhash: latestBlockhash.blockhash,
  // //         lastValidBlockHeight: latestBlockhash.lastValidBlockHeight,
  // //       },
  // //       "confirmed" // Set the desired confirmation level here
  // //     );

  // //     if (confirmation.value.err) {
  // //       console.error("Transaction failed:", confirmation.value.err);
  // //       throw new Error("Transaction failed");
  // //     }

  // //     console.log("Transaction confirmed successfully");

  // //     // Fetch the transaction details using getTransaction
  // //     const transactionDetails = await connection.getTransaction(signature, {
  // //       commitment: "confirmed",
  // //     });

  // //     console.log(transactionDetails.meta.logMessages);
  // //   } catch (error) {
  // //     console.log(error);
  // //     throw error;
  // //   }
  // // });

  // it("mint the token to user 4", async () => {
  //   try {
  //     await airdrop(payer4.publicKey);

  //     associatedTokenAccountAddress4 = getAssociatedTokenAddressSync(
  //       mint,
  //       payer4.publicKey
  //     );

  //     const ix = await program.methods
  //       .mint(mintAmount)
  //       .accounts({
  //         payer: payer4.publicKey,
  //       })
  //       .instruction();

  //     const tx = new Transaction();
  //     tx.add(ix);

  //     const signature = await connection.sendTransaction(tx, [payer4], {
  //       skipPreflight: false,
  //       preflightCommitment: "confirmed", // Set preflight commitment level
  //     });

  //     console.log("Transaction sent with signature:", signature);

  //     // Wait for confirmation
  //     const latestBlockhash = await connection.getLatestBlockhash();
  //     const confirmation = await connection.confirmTransaction(
  //       {
  //         signature,
  //         blockhash: latestBlockhash.blockhash,
  //         lastValidBlockHeight: latestBlockhash.lastValidBlockHeight,
  //       },
  //       "confirmed" // Set the desired confirmation level here
  //     );

  //     if (confirmation.value.err) {
  //       console.error("Transaction failed:", confirmation.value.err);
  //       throw new Error("Transaction failed");
  //     }

  //     console.log("Transaction confirmed successfully");

  //     // Fetch the transaction details using getTransaction
  //     const transactionDetails = await connection.getTransaction(signature, {
  //       commitment: "confirmed",
  //     });

  //     // Display transaction logs
  //     console.log(transactionDetails.meta.logMessages);
  //   } catch (error) {
  //     console.log(error);
  //   }
  // });

  // it("user 4 generate referral code", async () => {
  //   try {
  //     // const userAccount = await program.account.userAccount.fetch(user4Pda);

  //     let referredCode;

  //     try {
  //       // Try to fetch the user account
  //       const userAccount = await program.account.userAccount.fetch(user4Pda);
  //       referredCode = new PublicKey(userAccount.referredCode);
  //     } catch (error) {
  //       // If fetching the user account fails, use the alternative
  //       if (error.message.includes("Account does not exist or has no data")) {
  //         referredCode = payer3.publicKey;
  //       } else {
  //         // Re-throw other unexpected errors
  //         throw error;
  //       }
  //     }
  //     const [correctReferredPDA] = PublicKey.findProgramAddressSync(
  //       [Buffer.from(REFERRED_SEED), referredCode.toBuffer()],
  //       program.programId
  //     );

  //     const [referrerAccountPDA] = PublicKey.findProgramAddressSync(
  //       [Buffer.from(USER_SEED), referredCode.toBuffer()],
  //       program.programId
  //     );

  //     const Args = {
  //       referredCode: referredCode || null,
  //     };

  //     const ix = await program.methods
  //       .referralCode(Args)
  //       .accounts({
  //         payer: payer4.publicKey,
  //         referredState: correctReferredPDA,
  //         referrerAccount: referrerAccountPDA,
  //       })
  //       .instruction();

  //     const tx = new Transaction();
  //     tx.add(ix);

  //     const signature = await connection.sendTransaction(tx, [payer4], {
  //       skipPreflight: false,
  //       preflightCommitment: "confirmed", // Set preflight commitment level
  //     });

  //     console.log("Transaction sent with signature:", signature);

  //     // Wait for confirmation
  //     const latestBlockhash = await connection.getLatestBlockhash();
  //     const confirmation = await connection.confirmTransaction(
  //       {
  //         signature,
  //         blockhash: latestBlockhash.blockhash,
  //         lastValidBlockHeight: latestBlockhash.lastValidBlockHeight,
  //       },
  //       "confirmed" // Set the desired confirmation level here
  //     );

  //     if (confirmation.value.err) {
  //       console.error("Transaction failed:", confirmation.value.err);
  //       throw new Error("Transaction failed");
  //     }

  //     console.log("Transaction confirmed successfully");

  //     // Fetch the transaction details using getTransaction
  //     const transactionDetails = await connection.getTransaction(signature, {
  //       commitment: "confirmed",
  //     });

  //     // Display transaction logs
  //     console.log(transactionDetails.meta.logMessages);
  //   } catch (error) {
  //     console.log(error);
  //     throw error;
  //   }
  // });

  // it("user 4 staking the token", async () => {
  //   try {
  //     associatedTokenAccountAddress4 = getAssociatedTokenAddressSync(
  //       mint,
  //       payer4.publicKey
  //     );

  //     treasuryAssociatedTokenAccountAddress = getAssociatedTokenAddressSync(
  //       mint,
  //       treasury.publicKey
  //     );

  //     let referredCode;

  //     try {
  //       // Try to fetch the user account
  //       const userAccount = await program.account.userAccount.fetch(user4Pda);
  //       console.log("user 4 1234");
  //       referredCode = new PublicKey(userAccount.referredCode);
  //     } catch (error) {
  //       // If fetching the user account fails, use the alternative
  //       if (error.message.includes("Account does not exist or has no data")) {
  //         console.log("user 4 5678");
  //         referredCode = payer3.publicKey;
  //       } else {
  //         // Re-throw other unexpected errors
  //         throw error;
  //       }
  //     }

  //     const [correctReferredPDA] = PublicKey.findProgramAddressSync(
  //       [Buffer.from(USER_SEED), referredCode.toBuffer()],
  //       program.programId
  //     );
  //     let referrerATA;
  //     referrerATA = await getAssociatedTokenAddressSync(mint, referredCode);

  //     const accounts = {
  //       payer: payer4.publicKey,
  //       userTokenAta: associatedTokenAccountAddress4,
  //       treasuryWalletTokenAta: treasuryAssociatedTokenAccountAddress,
  //       referrerAccount: correctReferredPDA || null,
  //       referrerTokenAta: referrerATA || null,
  //     };

  //     const ArgsStake = {
  //       referredCode: referredCode || null,
  //       stakeAmount: stakeAmount,
  //     };

  //     const ix = await program.methods
  //       .createStake(ArgsStake)
  //       .accounts(accounts)
  //       .instruction();

  //     const tx = new Transaction();
  //     tx.add(ix);

  //     const signature = await connection.sendTransaction(tx, [payer4], {
  //       skipPreflight: false,
  //       preflightCommitment: "confirmed", // Set preflight commitment level
  //     });

  //     console.log("Transaction sent with signature:", signature);

  //     // Wait for confirmation
  //     const latestBlockhash = await connection.getLatestBlockhash();
  //     const confirmation = await connection.confirmTransaction(
  //       {
  //         signature,
  //         blockhash: latestBlockhash.blockhash,
  //         lastValidBlockHeight: latestBlockhash.lastValidBlockHeight,
  //       },
  //       "confirmed" // Set the desired confirmation level here
  //     );

  //     if (confirmation.value.err) {
  //       console.error("Transaction failed:", confirmation.value.err);
  //       throw new Error("Transaction failed");
  //     }

  //     console.log("Transaction confirmed successfully");

  //     // Fetch the transaction details using getTransaction
  //     const transactionDetails = await connection.getTransaction(signature, {
  //       commitment: "confirmed",
  //     });

  //     // Display transaction logs
  //     console.log(transactionDetails.meta.logMessages);
  //   } catch (error) {
  //     console.log(error);
  //     throw error;
  //   }
  // });

  // it("Show the reward for user 4", async () => {
  //   try {
  //     // await new Promise((resolve) => setTimeout(resolve, 1000));
  //     const ix = await program.methods
  //       .showRewards()
  //       .accounts({
  //         payer: payer4.publicKey,
  //       })
  //       .instruction();

  //     const tx = new Transaction();
  //     tx.add(ix);

  //     const signature = await connection.sendTransaction(tx, [payer4], {
  //       skipPreflight: false,
  //       preflightCommitment: "confirmed", // Set preflight commitment level
  //     });

  //     console.log("Transaction sent with signature:", signature);

  //     // Wait for confirmation
  //     const latestBlockhash = await connection.getLatestBlockhash();
  //     const confirmation = await connection.confirmTransaction(
  //       {
  //         signature,
  //         blockhash: latestBlockhash.blockhash,
  //         lastValidBlockHeight: latestBlockhash.lastValidBlockHeight,
  //       },
  //       "confirmed" // Set the desired confirmation level here
  //     );

  //     if (confirmation.value.err) {
  //       console.error("Transaction failed:", confirmation.value.err);
  //       throw new Error("Transaction failed");
  //     }

  //     console.log("Transaction confirmed successfully");

  //     // Fetch the transaction details using getTransaction
  //     const transactionDetails = await connection.getTransaction(signature, {
  //       commitment: "confirmed",
  //     });

  //     // Display transaction logs
  //     console.log(transactionDetails.meta.logMessages);
  //   } catch (error) {
  //     console.log(error);
  //     throw error;
  //   }
  // });

  // // it("User 5 registered with referral code  of user 4", async () => {
  // //   try {
  // //     await airdrop(payer5.publicKey);

  // //     referredCode = payer4.publicKey;
  // //     const [correctReferredPDA] = PublicKey.findProgramAddressSync(
  // //       [Buffer.from(USER_SEED), referredCode.toBuffer()],
  // //       program.programId
  // //     );

  // //     const ix = await program.methods
  // //       .userRegister({ referredCode })
  // //       .accounts({
  // //         payer: payer5.publicKey,
  // //         referrerAccount: correctReferredPDA,
  // //       })
  // //       .instruction();

  // //     const tx = new Transaction();
  // //     tx.add(ix);

  // //     const signature = await connection.sendTransaction(tx, [payer5], {
  // //       skipPreflight: false,
  // //       preflightCommitment: "confirmed", // Set preflight commitment level
  // //     });

  // //     console.log("Transaction sent with signature:", signature);

  // //     // Wait for confirmation
  // //     const latestBlockhash = await connection.getLatestBlockhash();
  // //     const confirmation = await connection.confirmTransaction(
  // //       {
  // //         signature,
  // //         blockhash: latestBlockhash.blockhash,
  // //         lastValidBlockHeight: latestBlockhash.lastValidBlockHeight,
  // //       },
  // //       "confirmed" // Set the desired confirmation level here
  // //     );

  // //     if (confirmation.value.err) {
  // //       console.error("Transaction failed:", confirmation.value.err);
  // //       throw new Error("Transaction failed");
  // //     }

  // //     console.log("Transaction confirmed successfully");

  // //     // Fetch the transaction details using getTransaction
  // //     const transactionDetails = await connection.getTransaction(signature, {
  // //       commitment: "confirmed",
  // //     });

  // //     console.log(transactionDetails.meta.logMessages);
  // //   } catch (error) {
  // //     console.log(error);
  // //     throw error;
  // //   }
  // // });

  // it("user 5 generate referral code", async () => {
  //   try {
  //     await airdrop(payer5.publicKey);
  //     let referredCode;

  //     try {
  //       // Try to fetch the user account
  //       const userAccount = await program.account.userAccount.fetch(user5Pda);
  //       referredCode = new PublicKey(userAccount.referredCode);
  //     } catch (error) {
  //       // If fetching the user account fails, use the alternative
  //       if (error.message.includes("Account does not exist or has no data")) {
  //         referredCode = payer4.publicKey;
  //       } else {
  //         // Re-throw other unexpected errors
  //         throw error;
  //       }
  //     }
  //     const [correctReferredPDA] = PublicKey.findProgramAddressSync(
  //       [Buffer.from(REFERRED_SEED), referredCode.toBuffer()],
  //       program.programId
  //     );

  //     const [referrerAccountPDA] = PublicKey.findProgramAddressSync(
  //       [Buffer.from(USER_SEED), referredCode.toBuffer()],
  //       program.programId
  //     );

  //     const Args = {
  //       referredCode: referredCode || null,
  //     };

  //     const ix = await program.methods
  //       .referralCode(Args)
  //       .accounts({
  //         payer: payer5.publicKey,
  //         referredState: correctReferredPDA || null,
  //         referrerAccount: referrerAccountPDA || null,
  //       })
  //       .instruction();

  //     const tx = new Transaction();
  //     tx.add(ix);

  //     const signature = await connection.sendTransaction(tx, [payer5], {
  //       skipPreflight: false,
  //       preflightCommitment: "confirmed", // Set preflight commitment level
  //     });

  //     console.log("Transaction sent with signature:", signature);

  //     // Wait for confirmation
  //     const latestBlockhash = await connection.getLatestBlockhash();
  //     const confirmation = await connection.confirmTransaction(
  //       {
  //         signature,
  //         blockhash: latestBlockhash.blockhash,
  //         lastValidBlockHeight: latestBlockhash.lastValidBlockHeight,
  //       },
  //       "confirmed" // Set the desired confirmation level here
  //     );

  //     if (confirmation.value.err) {
  //       console.error("Transaction failed:", confirmation.value.err);
  //       throw new Error("Transaction failed");
  //     }

  //     console.log("Transaction confirmed successfully");

  //     // Fetch the transaction details using getTransaction
  //     const transactionDetails = await connection.getTransaction(signature, {
  //       commitment: "confirmed",
  //     });

  //     // Display transaction logs
  //     console.log(transactionDetails.meta.logMessages);
  //   } catch (error) {
  //     console.log(error);
  //     throw error;
  //   }
  // });

  // // it("User 6 registered with referral code  of user 5", async () => {
  // //   try {
  // //     await airdrop(payer6.publicKey);

  // //     referredCode = payer5.publicKey;
  // //     const [correctReferredPDA] = PublicKey.findProgramAddressSync(
  // //       [Buffer.from(USER_SEED), referredCode.toBuffer()],
  // //       program.programId
  // //     );

  // //     const ix = await program.methods
  // //       .userRegister({ referredCode })
  // //       .accounts({
  // //         payer: payer6.publicKey,
  // //         referrerAccount: correctReferredPDA,
  // //       })
  // //       .instruction();

  // //     const tx = new Transaction();
  // //     tx.add(ix);

  // //     const signature = await connection.sendTransaction(tx, [payer6], {
  // //       skipPreflight: false,
  // //       preflightCommitment: "confirmed", // Set preflight commitment level
  // //     });

  // //     console.log("Transaction sent with signature:", signature);

  // //     // Wait for confirmation
  // //     const latestBlockhash = await connection.getLatestBlockhash();
  // //     const confirmation = await connection.confirmTransaction(
  // //       {
  // //         signature,
  // //         blockhash: latestBlockhash.blockhash,
  // //         lastValidBlockHeight: latestBlockhash.lastValidBlockHeight,
  // //       },
  // //       "confirmed" // Set the desired confirmation level here
  // //     );

  // //     if (confirmation.value.err) {
  // //       console.error("Transaction failed:", confirmation.value.err);
  // //       throw new Error("Transaction failed");
  // //     }

  // //     console.log("Transaction confirmed successfully");

  // //     // Fetch the transaction details using getTransaction
  // //     const transactionDetails = await connection.getTransaction(signature, {
  // //       commitment: "confirmed",
  // //     });

  // //     console.log(transactionDetails.meta.logMessages);
  // //   } catch (error) {
  // //     console.log(error);
  // //     throw error;
  // //   }
  // // });

  // it("user 6 generate referral code", async () => {
  //   try {
  //     await airdrop(payer6.publicKey);
  //     let referredCode;

  //     try {
  //       // Try to fetch the user account
  //       const userAccount = await program.account.userAccount.fetch(user6Pda);
  //       referredCode = new PublicKey(userAccount.referredCode);
  //     } catch (error) {
  //       // If fetching the user account fails, use the alternative
  //       if (error.message.includes("Account does not exist or has no data")) {
  //         referredCode = payer5.publicKey;
  //       } else {
  //         // Re-throw other unexpected errors
  //         throw error;
  //       }
  //     }
  //     const [correctReferredPDA] = PublicKey.findProgramAddressSync(
  //       [Buffer.from(REFERRED_SEED), referredCode.toBuffer()],
  //       program.programId
  //     );

  //     const [referrerAccountPDA] = PublicKey.findProgramAddressSync(
  //       [Buffer.from(USER_SEED), referredCode.toBuffer()],
  //       program.programId
  //     );

  //     const Args = {
  //       referredCode: referredCode || null,
  //     };

  //     const ix = await program.methods
  //       .referralCode(Args)
  //       .accounts({
  //         payer: payer6.publicKey,
  //         referredState: correctReferredPDA || null,
  //         referrerAccount: referrerAccountPDA || null,
  //       })
  //       .instruction();

  //     const tx = new Transaction();
  //     tx.add(ix);

  //     const signature = await connection.sendTransaction(tx, [payer6], {
  //       skipPreflight: false,
  //       preflightCommitment: "confirmed", // Set preflight commitment level
  //     });

  //     console.log("Transaction sent with signature:", signature);

  //     // Wait for confirmation
  //     const latestBlockhash = await connection.getLatestBlockhash();
  //     const confirmation = await connection.confirmTransaction(
  //       {
  //         signature,
  //         blockhash: latestBlockhash.blockhash,
  //         lastValidBlockHeight: latestBlockhash.lastValidBlockHeight,
  //       },
  //       "confirmed" // Set the desired confirmation level here
  //     );

  //     if (confirmation.value.err) {
  //       console.error("Transaction failed:", confirmation.value.err);
  //       throw new Error("Transaction failed");
  //     }

  //     console.log("Transaction confirmed successfully");

  //     // Fetch the transaction details using getTransaction
  //     const transactionDetails = await connection.getTransaction(signature, {
  //       commitment: "confirmed",
  //     });

  //     // Display transaction logs
  //     console.log(transactionDetails.meta.logMessages);
  //   } catch (error) {
  //     console.log(error);
  //     throw error;
  //   }
  // });

  // // it("User 7 registered with referral code  of user 6", async () => {
  // //   try {
  // //     await airdrop(payer7.publicKey);

  // //     referredCode = payer6.publicKey;
  // //     const [correctReferredPDA] = PublicKey.findProgramAddressSync(
  // //       [Buffer.from(USER_SEED), referredCode.toBuffer()],
  // //       program.programId
  // //     );

  // //     const ix = await program.methods
  // //       .userRegister({ referredCode })
  // //       .accounts({
  // //         payer: payer7.publicKey,
  // //         referrerAccount: correctReferredPDA,
  // //       })
  // //       .instruction();

  // //     const tx = new Transaction();
  // //     tx.add(ix);

  // //     const signature = await connection.sendTransaction(tx, [payer7], {
  // //       skipPreflight: false,
  // //       preflightCommitment: "confirmed", // Set preflight commitment level
  // //     });

  // //     console.log("Transaction sent with signature:", signature);

  // //     // Wait for confirmation
  // //     const latestBlockhash = await connection.getLatestBlockhash();
  // //     const confirmation = await connection.confirmTransaction(
  // //       {
  // //         signature,
  // //         blockhash: latestBlockhash.blockhash,
  // //         lastValidBlockHeight: latestBlockhash.lastValidBlockHeight,
  // //       },
  // //       "confirmed" // Set the desired confirmation level here
  // //     );

  // //     if (confirmation.value.err) {
  // //       console.error("Transaction failed:", confirmation.value.err);
  // //       throw new Error("Transaction failed");
  // //     }

  // //     console.log("Transaction confirmed successfully");

  // //     // Fetch the transaction details using getTransaction
  // //     const transactionDetails = await connection.getTransaction(signature, {
  // //       commitment: "confirmed",
  // //     });

  // //     console.log(transactionDetails.meta.logMessages);
  // //   } catch (error) {
  // //     console.log(error);
  // //     throw error;
  // //   }
  // // });

  // it("user 7 generate referral code", async () => {
  //   try {
  //     await airdrop(payer7.publicKey);
  //     let referredCode;

  //     try {
  //       // Try to fetch the user account
  //       const userAccount = await program.account.userAccount.fetch(user7Pda);
  //       referredCode = new PublicKey(userAccount.referredCode);
  //     } catch (error) {
  //       // If fetching the user account fails, use the alternative
  //       if (error.message.includes("Account does not exist or has no data")) {
  //         referredCode = payer6.publicKey;
  //       } else {
  //         // Re-throw other unexpected errors
  //         throw error;
  //       }
  //     }
  //     const [correctReferredPDA] = PublicKey.findProgramAddressSync(
  //       [Buffer.from(REFERRED_SEED), referredCode.toBuffer()],
  //       program.programId
  //     );

  //     const [referrerAccountPDA] = PublicKey.findProgramAddressSync(
  //       [Buffer.from(USER_SEED), referredCode.toBuffer()],
  //       program.programId
  //     );

  //     const Args = {
  //       referredCode: referredCode || null,
  //     };

  //     const ix = await program.methods
  //       .referralCode(Args)
  //       .accounts({
  //         payer: payer7.publicKey,
  //         referredState: correctReferredPDA || null,
  //         referrerAccount: referrerAccountPDA || null,
  //       })
  //       .instruction();

  //     const tx = new Transaction();
  //     tx.add(ix);

  //     const signature = await connection.sendTransaction(tx, [payer7], {
  //       skipPreflight: false,
  //       preflightCommitment: "confirmed", // Set preflight commitment level
  //     });

  //     console.log("Transaction sent with signature:", signature);

  //     // Wait for confirmation
  //     const latestBlockhash = await connection.getLatestBlockhash();
  //     const confirmation = await connection.confirmTransaction(
  //       {
  //         signature,
  //         blockhash: latestBlockhash.blockhash,
  //         lastValidBlockHeight: latestBlockhash.lastValidBlockHeight,
  //       },
  //       "confirmed" // Set the desired confirmation level here
  //     );

  //     if (confirmation.value.err) {
  //       console.error("Transaction failed:", confirmation.value.err);
  //       throw new Error("Transaction failed");
  //     }

  //     console.log("Transaction confirmed successfully");

  //     // Fetch the transaction details using getTransaction
  //     const transactionDetails = await connection.getTransaction(signature, {
  //       commitment: "confirmed",
  //     });

  //     // Display transaction logs
  //     console.log(transactionDetails.meta.logMessages);
  //   } catch (error) {
  //     console.log(error);
  //     throw error;
  //   }
  // });

  // // it("User 8 registered with referral code  of user 7", async () => {
  // //   try {
  // //     await airdrop(payer8.publicKey);

  // //     referredCode = payer7.publicKey;
  // //     const [correctReferredPDA] = PublicKey.findProgramAddressSync(
  // //       [Buffer.from(USER_SEED), referredCode.toBuffer()],
  // //       program.programId
  // //     );

  // //     const ix = await program.methods
  // //       .userRegister({ referredCode })
  // //       .accounts({
  // //         payer: payer8.publicKey,
  // //         referrerAccount: correctReferredPDA,
  // //       })
  // //       .instruction();

  // //     const tx = new Transaction();
  // //     tx.add(ix);

  // //     const signature = await connection.sendTransaction(tx, [payer8], {
  // //       skipPreflight: false,
  // //       preflightCommitment: "confirmed", // Set preflight commitment level
  // //     });

  // //     console.log("Transaction sent with signature:", signature);

  // //     // Wait for confirmation
  // //     const latestBlockhash = await connection.getLatestBlockhash();
  // //     const confirmation = await connection.confirmTransaction(
  // //       {
  // //         signature,
  // //         blockhash: latestBlockhash.blockhash,
  // //         lastValidBlockHeight: latestBlockhash.lastValidBlockHeight,
  // //       },
  // //       "confirmed" // Set the desired confirmation level here
  // //     );

  // //     if (confirmation.value.err) {
  // //       console.error("Transaction failed:", confirmation.value.err);
  // //       throw new Error("Transaction failed");
  // //     }

  // //     console.log("Transaction confirmed successfully");

  // //     // Fetch the transaction details using getTransaction
  // //     const transactionDetails = await connection.getTransaction(signature, {
  // //       commitment: "confirmed",
  // //     });

  // //     console.log(transactionDetails.meta.logMessages);
  // //   } catch (error) {
  // //     console.log(error);
  // //     throw error;
  // //   }
  // // });

  // it("user 8 generate referral code", async () => {
  //   try {
  //     await airdrop(payer8.publicKey);
  //     let referredCode;

  //     try {
  //       // Try to fetch the user account
  //       const userAccount = await program.account.userAccount.fetch(user8Pda);
  //       referredCode = new PublicKey(userAccount.referredCode);
  //     } catch (error) {
  //       // If fetching the user account fails, use the alternative
  //       if (error.message.includes("Account does not exist or has no data")) {
  //         referredCode = payer7.publicKey;
  //       } else {
  //         // Re-throw other unexpected errors
  //         throw error;
  //       }
  //     }
  //     const [correctReferredPDA] = PublicKey.findProgramAddressSync(
  //       [Buffer.from(REFERRED_SEED), referredCode.toBuffer()],
  //       program.programId
  //     );

  //     const [referrerAccountPDA] = PublicKey.findProgramAddressSync(
  //       [Buffer.from(USER_SEED), referredCode.toBuffer()],
  //       program.programId
  //     );

  //     const Args = {
  //       referredCode: referredCode || null,
  //     };

  //     const ix = await program.methods
  //       .referralCode(Args)
  //       .accounts({
  //         payer: payer8.publicKey,
  //         referredState: correctReferredPDA || null,
  //         referrerAccount: referrerAccountPDA || null,
  //       })
  //       .instruction();

  //     const tx = new Transaction();
  //     tx.add(ix);

  //     const signature = await connection.sendTransaction(tx, [payer8], {
  //       skipPreflight: false,
  //       preflightCommitment: "confirmed", // Set preflight commitment level
  //     });

  //     console.log("Transaction sent with signature:", signature);

  //     // Wait for confirmation
  //     const latestBlockhash = await connection.getLatestBlockhash();
  //     const confirmation = await connection.confirmTransaction(
  //       {
  //         signature,
  //         blockhash: latestBlockhash.blockhash,
  //         lastValidBlockHeight: latestBlockhash.lastValidBlockHeight,
  //       },
  //       "confirmed" // Set the desired confirmation level here
  //     );

  //     if (confirmation.value.err) {
  //       console.error("Transaction failed:", confirmation.value.err);
  //       throw new Error("Transaction failed");
  //     }

  //     console.log("Transaction confirmed successfully");

  //     // Fetch the transaction details using getTransaction
  //     const transactionDetails = await connection.getTransaction(signature, {
  //       commitment: "confirmed",
  //     });

  //     // Display transaction logs
  //     console.log(transactionDetails.meta.logMessages);
  //   } catch (error) {
  //     console.log(error);
  //     throw error;
  //   }
  // });

  // // it("User 9 registered with referral code  of user 8", async () => {
  // //   try {
  // //     await airdrop(payer9.publicKey);

  // //     referredCode = payer8.publicKey;
  // //     const [correctReferredPDA] = PublicKey.findProgramAddressSync(
  // //       [Buffer.from(USER_SEED), referredCode.toBuffer()],
  // //       program.programId
  // //     );

  // //     const ix = await program.methods
  // //       .userRegister({ referredCode })
  // //       .accounts({
  // //         payer: payer9.publicKey,
  // //         referrerAccount: correctReferredPDA,
  // //       })
  // //       .instruction();

  // //     const tx = new Transaction();
  // //     tx.add(ix);

  // //     const signature = await connection.sendTransaction(tx, [payer9], {
  // //       skipPreflight: false,
  // //       preflightCommitment: "confirmed", // Set preflight commitment level
  // //     });

  // //     console.log("Transaction sent with signature:", signature);

  // //     // Wait for confirmation
  // //     const latestBlockhash = await connection.getLatestBlockhash();
  // //     const confirmation = await connection.confirmTransaction(
  // //       {
  // //         signature,
  // //         blockhash: latestBlockhash.blockhash,
  // //         lastValidBlockHeight: latestBlockhash.lastValidBlockHeight,
  // //       },
  // //       "confirmed" // Set the desired confirmation level here
  // //     );

  // //     if (confirmation.value.err) {
  // //       console.error("Transaction failed:", confirmation.value.err);
  // //       throw new Error("Transaction failed");
  // //     }

  // //     console.log("Transaction confirmed successfully");

  // //     // Fetch the transaction details using getTransaction
  // //     const transactionDetails = await connection.getTransaction(signature, {
  // //       commitment: "confirmed",
  // //     });

  // //     console.log(transactionDetails.meta.logMessages);
  // //   } catch (error) {
  // //     console.log(error);
  // //     throw error;
  // //   }
  // // });

  // it("mint the token to user 9", async () => {
  //   await airdrop(payer9.publicKey);
  //   try {
  //     associatedTokenAccountAddress9 = getAssociatedTokenAddressSync(
  //       mint,
  //       payer9.publicKey
  //     );

  //     const ix = await program.methods
  //       .mint(mintAmount)
  //       .accounts({
  //         payer: payer9.publicKey,
  //       })
  //       .instruction();

  //     const tx = new Transaction();
  //     tx.add(ix);

  //     const signature = await connection.sendTransaction(tx, [payer9], {
  //       skipPreflight: false,
  //       preflightCommitment: "confirmed", // Set preflight commitment level
  //     });

  //     console.log("Transaction sent with signature:", signature);

  //     // Wait for confirmation
  //     const latestBlockhash = await connection.getLatestBlockhash();
  //     const confirmation = await connection.confirmTransaction(
  //       {
  //         signature,
  //         blockhash: latestBlockhash.blockhash,
  //         lastValidBlockHeight: latestBlockhash.lastValidBlockHeight,
  //       },
  //       "confirmed" // Set the desired confirmation level here
  //     );

  //     if (confirmation.value.err) {
  //       console.error("Transaction failed:", confirmation.value.err);
  //       throw new Error("Transaction failed");
  //     }

  //     console.log("Transaction confirmed successfully");

  //     // Fetch the transaction details using getTransaction
  //     const transactionDetails = await connection.getTransaction(signature, {
  //       commitment: "confirmed",
  //     });

  //     // Display transaction logs
  //     console.log(transactionDetails.meta.logMessages);
  //   } catch (error) {
  //     console.log(error);
  //   }
  // });

  it("user 9 staking the token", async () => {
    try {
      associatedTokenAccountAddress9 = getAssociatedTokenAddressSync(
        mint,
        payer9.publicKey
      );

      treasuryAssociatedTokenAccountAddress = getAssociatedTokenAddressSync(
        mint,
        treasury.publicKey
      );

      let referredCode;

      try {
        // Try to fetch the user account
        const userAccount = await program.account.userAccount.fetch(user9Pda);
        referredCode = new PublicKey(userAccount.referredCode);
      } catch (error) {
        // If fetching the user account fails, use the alternative
        if (error.message.includes("Account does not exist or has no data")) {
          referredCode = payer8.publicKey;
        } else {
          // Re-throw other unexpected errors
          throw error;
        }
      }

      const [correctReferredPDA] = PublicKey.findProgramAddressSync(
        [Buffer.from(USER_SEED), referredCode.toBuffer()],
        program.programId
      );
      let referrerATA;
      referrerATA = await getAssociatedTokenAddressSync(mint, referredCode);

      const accounts = {
        payer: payer9.publicKey,
        userTokenAta: associatedTokenAccountAddress9,
        treasuryWalletTokenAta: treasuryAssociatedTokenAccountAddress,
        referrerAccount: correctReferredPDA || null,
        referrerTokenAta: referrerATA || null,
      };
      const ArgsStake = {
        referredCode: referredCode || null,
        stakeAmount: stakeAmount,
      };
      const ix = await program.methods
        .createStake(ArgsStake)
        .accounts(accounts)
        .instruction();

      const tx = new Transaction();
      tx.add(ix);

      const signature = await connection.sendTransaction(tx, [payer9], {
        skipPreflight: false,
        preflightCommitment: "confirmed", // Set preflight commitment level
      });

      console.log("Transaction sent with signature:", signature);

      // Wait for confirmation
      const latestBlockhash = await connection.getLatestBlockhash();
      const confirmation = await connection.confirmTransaction(
        {
          signature,
          blockhash: latestBlockhash.blockhash,
          lastValidBlockHeight: latestBlockhash.lastValidBlockHeight,
        },
        "confirmed" // Set the desired confirmation level here
      );

      if (confirmation.value.err) {
        console.error("Transaction failed:", confirmation.value.err);
        throw new Error("Transaction failed");
      }

      console.log("Transaction confirmed successfully");

      // Fetch the transaction details using getTransaction
      const transactionDetails = await connection.getTransaction(signature, {
        commitment: "confirmed",
      });

      // Display transaction logs
      console.log(transactionDetails.meta.logMessages);
    } catch (error) {
      console.log(error);
      throw error;
    }
  });
  // it("Withdraw the rewards for the user 1 ", async () => {
  //   try {
  //     const ix = await program.methods
  //       .withdrawRewards()
  //       .accounts({
  //         payer: payer.publicKey,
  //         userTokenAta: associatedTokenAccountAddress,
  //         treasuryWalletTokenAta: treasuryAssociatedTokenAccountAddress,
  //         referrerTokenAta: null,
  //         referrerAccount: null,
  //       })
  //       .instruction();

  //     const tx = new Transaction();
  //     tx.add(ix);

  //     const signature = await connection.sendTransaction(tx, [payer], {
  //       skipPreflight: false,
  //       preflightCommitment: "confirmed", // Set preflight commitment level
  //     });

  //     console.log("Transaction sent with signature:", signature);

  //     // Wait for confirmation
  //     const latestBlockhash = await connection.getLatestBlockhash();
  //     const confirmation = await connection.confirmTransaction(
  //       {
  //         signature,
  //         blockhash: latestBlockhash.blockhash,
  //         lastValidBlockHeight: latestBlockhash.lastValidBlockHeight,
  //       },
  //       "confirmed" // Set the desired confirmation level here
  //     );

  //     if (confirmation.value.err) {
  //       console.error("Transaction failed:", confirmation.value.err);
  //       throw new Error("Transaction failed");
  //     }

  //     console.log("Transaction confirmed successfully");

  //     // Fetch the transaction details using getTransaction
  //     const transactionDetails = await connection.getTransaction(signature, {
  //       commitment: "confirmed",
  //     });

  //     // Display transaction logs
  //     console.log(transactionDetails.meta.logMessages);
  //   } catch (error) {
  //     console.log(error);
  //     throw error;
  //   }
  // });

  // // it("Set the reward rate 2 for the users ", async () => {
  // //   try {
  // //     rewardRate = 100.0;
  // //     const ix = await program.methods
  // //       .apy(rewardRate)
  // //       .accounts({ payer: payer.publicKey })
  // //       .instruction();

  // //     const tx = new Transaction();
  // //     tx.add(ix);

  // //     const signature = await connection.sendTransaction(tx, [payer], {
  // //       skipPreflight: false,
  // //       preflightCommitment: "confirmed", // Set preflight commitment level
  // //     });

  // //     console.log("Transaction sent with signature:", signature);

  // //     // Wait for confirmation
  // //     const latestBlockhash = await connection.getLatestBlockhash();
  // //     const confirmation = await connection.confirmTransaction(
  // //       {
  // //         signature,
  // //         blockhash: latestBlockhash.blockhash,
  // //         lastValidBlockHeight: latestBlockhash.lastValidBlockHeight,
  // //       },
  // //       "confirmed" // Set the desired confirmation level here
  // //     );

  // //     if (confirmation.value.err) {
  // //       console.error("Transaction failed:", confirmation.value.err);
  // //       throw new Error("Transaction failed");
  // //     }

  // //     console.log("Transaction confirmed successfully");

  // //     // Fetch the transaction details using getTransaction
  // //     const transactionDetails = await connection.getTransaction(signature, {
  // //       commitment: "confirmed",
  // //     });

  // //     // Display transaction logs
  // //     console.log(transactionDetails.meta.logMessages);
  // //     await new Promise((resolve) => setTimeout(resolve, 1000));
  // //   } catch (error) {
  // //     console.log(error);
  // //     throw error;
  // //   }
  // // });

  // // it("User 1 stake the token", async () => {
  // //   try {
  // //     const accounts = {
  // //       payer: payer.publicKey,
  // //       userTokenAta: associatedTokenAccountAddress,
  // //       treasuryWalletTokenAta: treasuryAssociatedTokenAccountAddress,
  // //       referrerAccount: null,
  // //       referrerTokenAta: null,
  // //     };
  // //     const ArgsStake = {
  // //       referredCode: null,
  // //       stakeAmount: stakeAmount,
  // //     };
  // //     const ix = await program.methods
  // //       .createStake(ArgsStake)
  // //       .accounts(accounts)
  // //       .instruction();

  // //     const tx = new Transaction();
  // //     tx.add(ix);

  // //     const signature = await connection.sendTransaction(tx, [payer], {
  // //       skipPreflight: false,
  // //       preflightCommitment: "confirmed", // Set preflight commitment level
  // //     });

  // //     console.log("Transaction sent with signature:", signature);

  // //     // Wait for confirmation
  // //     const latestBlockhash = await connection.getLatestBlockhash();
  // //     const confirmation = await connection.confirmTransaction(
  // //       {
  // //         signature,
  // //         blockhash: latestBlockhash.blockhash,
  // //         lastValidBlockHeight: latestBlockhash.lastValidBlockHeight,
  // //       },
  // //       "confirmed" // Set the desired confirmation level here
  // //     );

  // //     if (confirmation.value.err) {
  // //       console.error("Transaction failed:", confirmation.value.err);
  // //       throw new Error("Transaction failed");
  // //     }

  // //     console.log("Transaction confirmed successfully");

  // //     // Fetch the transaction details using getTransaction
  // //     const transactionDetails = await connection.getTransaction(signature, {
  // //       commitment: "confirmed",
  // //     });

  // //     // Display transaction logs
  // //     console.log(transactionDetails.meta.logMessages);
  // //     await new Promise((resolve) => setTimeout(resolve, 1000));
  // //   } catch (error) {
  // //     console.log(error);
  // //     throw error;
  // //   }
  // // });

  // // it("Withdraw the rewards for the user 1 ", async () => {
  // //   try {
  // //     const ix = await program.methods
  // //       .withdrawRewards()
  // //       .accounts({
  // //         payer: payer.publicKey,
  // //         userTokenAta: associatedTokenAccountAddress,
  // //         treasuryWalletTokenAta: treasuryAssociatedTokenAccountAddress,
  // //         referrerTokenAta: null,
  // //         referrerAccount: null,
  // //       })
  // //       .instruction();

  // //     const tx = new Transaction();
  // //     tx.add(ix);

  // //     const signature = await connection.sendTransaction(tx, [payer], {
  // //       skipPreflight: false,
  // //       preflightCommitment: "confirmed", // Set preflight commitment level
  // //     });

  // //     console.log("Transaction sent with signature:", signature);

  // //     // Wait for confirmation
  // //     const latestBlockhash = await connection.getLatestBlockhash();
  // //     const confirmation = await connection.confirmTransaction(
  // //       {
  // //         signature,
  // //         blockhash: latestBlockhash.blockhash,
  // //         lastValidBlockHeight: latestBlockhash.lastValidBlockHeight,
  // //       },
  // //       "confirmed" // Set the desired confirmation level here
  // //     );

  // //     if (confirmation.value.err) {
  // //       console.error("Transaction failed:", confirmation.value.err);
  // //       throw new Error("Transaction failed");
  // //     }

  // //     console.log("Transaction confirmed successfully");

  // //     // Fetch the transaction details using getTransaction
  // //     const transactionDetails = await connection.getTransaction(signature, {
  // //       commitment: "confirmed",
  // //     });

  // //     // Display transaction logs
  // //     console.log(transactionDetails.meta.logMessages);
  // //   } catch (error) {
  // //     console.log(error);
  // //     throw error;
  // //   }
  // // });

  // it("Withdraw the rewards for the user 2", async () => {
  //   try {
  //     const userAccount = await program.account.userAccount.fetch(user2Pda);
  //     let referredCode = new PublicKey(userAccount.referredCode);
  //     const [referrerAccountPDA] = PublicKey.findProgramAddressSync(
  //       [Buffer.from(USER_SEED), referredCode.toBuffer()],
  //       program.programId
  //     );

  //     const referrerAccount = await program.account.userAccount.fetch(
  //       referrerAccountPDA
  //     );
  //     let correctReferredPDA;
  //     let referrerFirstLevelAssociatedTokenAccountAddress;

  //     if (referrerAccount.level == new anchor.BN(1)) {
  //       correctReferredPDA = referrerAccountPDA;
  //       referrerFirstLevelAssociatedTokenAccountAddress =
  //         getAssociatedTokenAddressSync(mint, referredCode);
  //     } else {
  //       correctReferredPDA = null;
  //       referrerFirstLevelAssociatedTokenAccountAddress = null;
  //     }

  //     const ix = await program.methods
  //       .withdrawRewards()
  //       .accounts({
  //         payer: payer2.publicKey,
  //         userTokenAta: associatedTokenAccountAddress2,
  //         treasuryWalletTokenAta: treasuryAssociatedTokenAccountAddress,
  //         referrerAccount: correctReferredPDA,
  //         referrerTokenAta: referrerFirstLevelAssociatedTokenAccountAddress,
  //       })
  //       .instruction();

  //     const tx = new Transaction();
  //     tx.add(ix);

  //     const signature = await connection.sendTransaction(tx, [payer2], {
  //       skipPreflight: false,
  //       preflightCommitment: "confirmed", // Set preflight commitment level
  //     });

  //     console.log("Transaction sent with signature:", signature);

  //     // Wait for confirmation
  //     const latestBlockhash = await connection.getLatestBlockhash();
  //     const confirmation = await connection.confirmTransaction(
  //       {
  //         signature,
  //         blockhash: latestBlockhash.blockhash,
  //         lastValidBlockHeight: latestBlockhash.lastValidBlockHeight,
  //       },
  //       "confirmed" // Set the desired confirmation level here
  //     );

  //     if (confirmation.value.err) {
  //       console.error("Transaction failed:", confirmation.value.err);
  //       throw new Error("Transaction failed");
  //     }

  //     console.log("Transaction confirmed successfully");

  //     // Fetch the transaction details using getTransaction
  //     const transactionDetails = await connection.getTransaction(signature, {
  //       commitment: "confirmed",
  //     });

  //     // Display transaction logs
  //     console.log(transactionDetails.meta.logMessages);
  //   } catch (error) {
  //     console.log(error);
  //     throw error;
  //   }
  // });

  // it("Withdraw the rewards for the user 4", async () => {
  //   try {
  //     const userAccount = await program.account.userAccount.fetch(user4Pda);
  //     let referredCode = new PublicKey(userAccount.referredCode);
  //     const [referrerAccountPDA] = PublicKey.findProgramAddressSync(
  //       [Buffer.from(USER_SEED), referredCode.toBuffer()],
  //       program.programId
  //     );

  //     const referrerAccount = await program.account.userAccount.fetch(
  //       referrerAccountPDA
  //     );
  //     let correctReferredPDA;
  //     let referrerFirstLevelAssociatedTokenAccountAddress;

  //     if (referrerAccount.level == new anchor.BN(1)) {
  //       correctReferredPDA = referrerAccountPDA;
  //       referrerFirstLevelAssociatedTokenAccountAddress =
  //         getAssociatedTokenAddressSync(mint, referredCode);
  //     } else {
  //       correctReferredPDA = null;
  //       referrerFirstLevelAssociatedTokenAccountAddress = null;
  //     }

  //     const ix = await program.methods
  //       .withdrawRewards()
  //       .accounts({
  //         payer: payer4.publicKey,
  //         userTokenAta: associatedTokenAccountAddress4,
  //         treasuryWalletTokenAta: treasuryAssociatedTokenAccountAddress,
  //         referrerAccount: correctReferredPDA,
  //         referrerTokenAta: referrerFirstLevelAssociatedTokenAccountAddress,
  //       })
  //       .instruction();

  //     const tx = new Transaction();
  //     tx.add(ix);

  //     const signature = await connection.sendTransaction(tx, [payer4], {
  //       skipPreflight: false,
  //       preflightCommitment: "confirmed", // Set preflight commitment level
  //     });

  //     console.log("Transaction sent with signature:", signature);

  //     // Wait for confirmation
  //     const latestBlockhash = await connection.getLatestBlockhash();
  //     const confirmation = await connection.confirmTransaction(
  //       {
  //         signature,
  //         blockhash: latestBlockhash.blockhash,
  //         lastValidBlockHeight: latestBlockhash.lastValidBlockHeight,
  //       },
  //       "confirmed" // Set the desired confirmation level here
  //     );

  //     if (confirmation.value.err) {
  //       console.error("Transaction failed:", confirmation.value.err);
  //       throw new Error("Transaction failed");
  //     }

  //     console.log("Transaction confirmed successfully");

  //     // Fetch the transaction details using getTransaction
  //     const transactionDetails = await connection.getTransaction(signature, {
  //       commitment: "confirmed",
  //     });

  //     // Display transaction logs
  //     console.log(transactionDetails.meta.logMessages);
  //   } catch (error) {
  //     console.log(error);
  //     throw error;
  //   }
  // });

  // it("Withdraw the rewards for the user 9", async () => {
  //   try {
  //     const userAccount = await program.account.userAccount.fetch(user9Pda);
  //     let referredCode = new PublicKey(userAccount.referredCode);
  //     const [referrerAccountPDA] = PublicKey.findProgramAddressSync(
  //       [Buffer.from(USER_SEED), referredCode.toBuffer()],
  //       program.programId
  //     );

  //     const referrerAccount = await program.account.userAccount.fetch(
  //       referrerAccountPDA
  //     );
  //     let correctReferredPDA;
  //     let referrerFirstLevelAssociatedTokenAccountAddress;

  //     if (referrerAccount.level == new anchor.BN(1)) {
  //       correctReferredPDA = referrerAccountPDA;
  //       referrerFirstLevelAssociatedTokenAccountAddress =
  //         getAssociatedTokenAddressSync(mint, referredCode);
  //     } else {
  //       correctReferredPDA = null;
  //       referrerFirstLevelAssociatedTokenAccountAddress = null;
  //     }

  //     const ix = await program.methods
  //       .withdrawRewards()
  //       .accounts({
  //         payer: payer9.publicKey,
  //         userTokenAta: associatedTokenAccountAddress9,
  //         treasuryWalletTokenAta: treasuryAssociatedTokenAccountAddress,
  //         referrerAccount: correctReferredPDA,
  //         referrerTokenAta: referrerFirstLevelAssociatedTokenAccountAddress,
  //       })
  //       .instruction();

  //     const tx = new Transaction();
  //     tx.add(ix);

  //     const signature = await connection.sendTransaction(tx, [payer9], {
  //       skipPreflight: false,
  //       preflightCommitment: "confirmed", // Set preflight commitment level
  //     });

  //     console.log("Transaction sent with signature:", signature);

  //     // Wait for confirmation
  //     const latestBlockhash = await connection.getLatestBlockhash();
  //     const confirmation = await connection.confirmTransaction(
  //       {
  //         signature,
  //         blockhash: latestBlockhash.blockhash,
  //         lastValidBlockHeight: latestBlockhash.lastValidBlockHeight,
  //       },
  //       "confirmed" // Set the desired confirmation level here
  //     );

  //     if (confirmation.value.err) {
  //       console.error("Transaction failed:", confirmation.value.err);
  //       throw new Error("Transaction failed");
  //     }

  //     console.log("Transaction confirmed successfully");

  //     // Fetch the transaction details using getTransaction
  //     const transactionDetails = await connection.getTransaction(signature, {
  //       commitment: "confirmed",
  //     });

  //     // Display transaction logs
  //     console.log(transactionDetails.meta.logMessages);
  //   } catch (error) {
  //     console.log(error);
  //     throw error;
  //   }
  // });
});
