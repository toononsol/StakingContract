
use anchor_lang::prelude::*;

#[event]
pub struct InitializeEvent {
    pub initializer: Pubkey, 
}

#[event]
pub struct APYEvent {
    pub apy_rate: f64,
    pub accumulated_reward_per_token: u128,
    pub last_update_time: u64
}

#[event]
pub struct TokenCreationEvent {
    pub mint_address: Pubkey,
    pub initial_mint_amount: u64,
}


#[event]
pub struct ReferralCodeEvent{
    pub referral_code: Pubkey,
    pub referred_code: Pubkey,
}

#[event]
pub struct StakingFeeEvent{
    pub staking_fee: f64,
}

#[event]
pub struct WithdrawRewardEvent{
    pub user: Pubkey,
    pub withdraw_amount_with_taxes: f64,
}

#[event]
pub struct CreateStakeEvent{
    pub user: Pubkey,
    pub stake_amount: f64,
    pub total_stake_amount: f64,
}

