use anchor_lang::prelude::*;
use crate::{ constant::*, state::*, event::*, error::* };

pub fn staking_fee_handler(ctx: Context<StakingFee>, fee: f64) -> Result<()> {
    if ctx.accounts.admin_account.admin_key.key() != ctx.accounts.payer.key() {
        return Err(StakeProgramError::Unauthorized.into());
    }
    // extra  staking fee should be 0 to 25
    if fee > 25.0 && fee > 0.0 {
        return Err(StakeProgramError::InvalidStakingFeeAmount.into());
    }
    let staking_fee_account = &mut ctx.accounts.staking_fee_account;

    staking_fee_account.staking_fee = fee;
    staking_fee_account.bump = ctx.bumps.staking_fee_account;

    emit!(StakingFeeEvent {
        staking_fee: staking_fee_account.staking_fee,
    });
    Ok(())
}
#[derive(Accounts)]
pub struct StakingFee<'info> {
    #[account(mut)]
    pub payer: Signer<'info>,

    #[account(
        init_if_needed,
        payer = payer,
        seeds = [STAKE_FEE_SEED],
        bump,
        space = 8 + StakingFeeAccount::INIT_SPACE
    )]
    pub staking_fee_account: Box<Account<'info, StakingFeeAccount>>,

    #[account(
        mut, 
        seeds = [ADMIN_SEED],
        bump =  admin_account.bump,
    )]
    pub admin_account: Account<'info, AdminAccount>,

    pub system_program: Program<'info, System>,
}
