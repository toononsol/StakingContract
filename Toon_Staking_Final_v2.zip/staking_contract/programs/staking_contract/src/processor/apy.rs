use anchor_lang::prelude::*;
use crate::{ constant::*, state::*, event::*, error::* };

const PRECISION: u128 = 1_000_000_000; // 1e12

#[derive(AnchorSerialize, AnchorDeserialize)]
pub struct RewardArgs {
    pub reward_rate: f64,
}

pub fn apy_handler(ctx: Context<RewardAPY>, args: RewardArgs) -> Result<()> {
    if ctx.accounts.admin_account.admin_key.key() != ctx.accounts.payer.key() {
        return Err(StakeProgramError::Unauthorized.into());
    }

    let current_timestamp = Clock::get()?.unix_timestamp as u64;
    let reward_account = &mut ctx.accounts.reward_account;

    update_global_reward(reward_account, current_timestamp)?;

    // Set the new APY rate
    reward_account.apy_rate = args.reward_rate;
    reward_account.bump = ctx.bumps.reward_account;

    emit!(APYEvent {
        apy_rate: reward_account.apy_rate,
        accumulated_reward_per_token: reward_account.accumulated_reward_per_token,
        last_update_time: reward_account.last_update_time,
    });

    Ok(())
}

fn update_global_reward(reward_account: &mut RewardAccount, current_timestamp: u64) -> Result<()> {
    if reward_account.total_staked == 0 {
        reward_account.last_update_time = current_timestamp;
        return Ok(());
    }

    let time_diff = current_timestamp - reward_account.last_update_time;
    let seconds_per_year: u64 = 365 * 86400;

    // Convert APY to a decimal (e.g., 100% APY becomes 1.0)
    let apy_decimal = reward_account.apy_rate / 100.0;

    // Calculate reward per token
    let reward_per_token = (apy_decimal * (time_diff as f64)) / (seconds_per_year as f64);

    // Scale reward per token to prevent floating-point inaccuracies
    let reward_per_token_scaled = (reward_per_token * (PRECISION as f64)) as u128;

    // Update accumulated_reward_per_token
    reward_account.accumulated_reward_per_token =
        reward_account.accumulated_reward_per_token.saturating_add(reward_per_token_scaled);

    // Update last_update_time
    reward_account.last_update_time = current_timestamp;

    Ok(())
}

#[derive(Accounts)]
pub struct RewardAPY<'info> {
    #[account(mut)]
    pub payer: Signer<'info>,
    #[account(
        init_if_needed,
        payer = payer,
        seeds = [APY_REWARDS_SEED],
        bump,
        space = 8 + RewardAccount::INIT_SPACE
    )]
    pub reward_account: Box<Account<'info, RewardAccount>>,

    #[account(
        mut, 
        seeds = [ADMIN_SEED],
        bump =  admin_account.bump,
    )]
    pub admin_account: Account<'info, AdminAccount>,

    pub system_program: Program<'info, System>,
}
